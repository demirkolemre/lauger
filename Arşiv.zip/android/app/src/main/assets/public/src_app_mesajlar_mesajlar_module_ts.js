(self["webpackChunkselsmart"] = self["webpackChunkselsmart"] || []).push([["src_app_mesajlar_mesajlar_module_ts"],{

/***/ 5107:
/*!*****************************************************!*\
  !*** ./src/app/mesajlar/mesajlar-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MesajlarPageRoutingModule": () => (/* binding */ MesajlarPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _mesajlar_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mesajlar.page */ 606);




const routes = [
    {
        path: '',
        component: _mesajlar_page__WEBPACK_IMPORTED_MODULE_0__.MesajlarPage
    }
];
let MesajlarPageRoutingModule = class MesajlarPageRoutingModule {
};
MesajlarPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MesajlarPageRoutingModule);



/***/ }),

/***/ 4910:
/*!*********************************************!*\
  !*** ./src/app/mesajlar/mesajlar.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MesajlarPageModule": () => (/* binding */ MesajlarPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 9122);
/* harmony import */ var _mesajlar_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mesajlar-routing.module */ 5107);
/* harmony import */ var _mesajlar_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mesajlar.page */ 606);







let MesajlarPageModule = class MesajlarPageModule {
};
MesajlarPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _mesajlar_routing_module__WEBPACK_IMPORTED_MODULE_0__.MesajlarPageRoutingModule
        ],
        declarations: [_mesajlar_page__WEBPACK_IMPORTED_MODULE_1__.MesajlarPage]
    })
], MesajlarPageModule);



/***/ }),

/***/ 606:
/*!*******************************************!*\
  !*** ./src/app/mesajlar/mesajlar.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MesajlarPage": () => (/* binding */ MesajlarPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _raw_loader_mesajlar_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./mesajlar.page.html */ 4063);
/* harmony import */ var _mesajlar_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mesajlar.page.scss */ 4343);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/fire/firestore */ 6717);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 9122);
/* harmony import */ var _services_profile_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/profile.service */ 7715);









let MesajlarPage = class MesajlarPage {
    constructor(router, firestore, profilservice, navctrl, routers, loadingCtrl) {
        this.router = router;
        this.firestore = firestore;
        this.profilservice = profilservice;
        this.navctrl = navctrl;
        this.routers = routers;
        this.loadingCtrl = loadingCtrl;
        this.gonderilen = 'hidden';
        this.mesajlarim = '';
        this.benimolanlar = [];
        this.onunkiler = [];
        this.veriler = [];
        this.veri = [];
        this.benimkiler = [];
        this.konusmalar = [];
        this.aradiklarim = [];
        this.arananidler = [];
        this.secilen = 'mesajlarim';
        this.a = {};
        this.b = {};
        this.onunlist = [];
        this.benimlist = [];
        this.onunolanlar = [];
        this.benimolan = [];
        this.loaded = false;
    }
    close() {
        this.router.navigateByUrl('/home');
    }
    /*
    async ionViewDidEnter() {
      this.aradiklarim = [];
      var aa = [];
      this.firestore.collectionGroup("kargolar").valueChanges().subscribe(at => {
        console.log(at);
        var a = [];
        a = at;
        for (let i = 0; i < at.length; i++) {
          if (a[i].kullanici_id == this.userid) {
            this.firestore.collection("mesajlar").doc(a[i].id).collection("msj").valueChanges().subscribe(ayr => {
              this.firestore.collection("kullanicilar").doc(ayr[0].from).valueChanges().subscribe(ana => {
                var b = {
                  data :ana,
                  adi: a[i],
                }
                this.arananidler.push(ayr);
                this.aradiklarim.push(b);
              });
            });
          }
        }
      });
    }*/
    ionViewWillEnter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            this.konusmalar = [];
            this.routers.queryParams.subscribe((params) => {
                // console.log(params);
                this.benimkiler = params.data;
                this.userid = params.userid;
            });
            this.profilservice.getUserProfile();
            this.benimolanlar = [];
            this.onunkiler = [];
            this.firestore
                .collectionGroup('kargolar')
                .valueChanges()
                .subscribe((ana) => {
                for (let index = 0; index < ana.length; index++) {
                    this.firestore
                        .collection('mesajlar')
                        .doc(ana[index].id)
                        .collection('msj')
                        .valueChanges()
                        .subscribe((ebe) => {
                        for (let i = 0; i < ebe.length; i++) {
                            //    console.log(ebe[i].msg + " ===" + ana[index].kullanici_id);
                            if (ana[index].kullanici_id == this.profilservice.useridsi) {
                                if (ebe[i].to == this.profilservice.useridsi &&
                                    ana[index].kullanici_id == this.profilservice.useridsi) {
                                    var a = {
                                        data: ana[index],
                                        user: ebe[i],
                                    };
                                    this.benimolan.push(a);
                                    this.benimlist.push(ana[index].kargo_adi);
                                }
                                else {
                                }
                            }
                            if (ebe[i].to == ana[index].kullanici_id &&
                                ana[index].kullanici_id != this.profilservice.useridsi) {
                                var b = {
                                    data: ana[index],
                                    user: ebe[i],
                                };
                                this.onunolanlar.push(b);
                                this.onunlist.push(ana[index].kargo_adi);
                            }
                        }
                    });
                }
                setTimeout(() => {
                    this.filtrele();
                }, 500);
            });
        });
    }
    filtrele() {
        const filitre = this.onunlist.filter((item, index) => {
            // Eğer mevcut öğenin indeksi aynı ise, yeni diziye dön.
            return this.onunlist.indexOf(item) === index;
        });
        this.onunkiler = filitre;
        const filitrebenim = this.benimlist.filter((itemm, indexx) => {
            // Eğer mevcut öğenin indeksi aynı ise, yeni diziye dön.
            return this.benimlist.indexOf(itemm) === indexx;
        });
        this.benimolanlar = filitrebenim;
        this.loaded = true;
    }
    tipsec(data) {
        this.secilen = data.detail.value;
        if (this.secilen == 'gönderilen') {
            this.gonderilen = '';
            this.mesajlarim = 'hidden';
            console.log(this.onunkiler);
        }
        else if (this.secilen == 'mesajlarim') {
            this.mesajlarim = '';
            this.gonderilen = 'hidden';
            console.log(this.benimolanlar);
        }
        console.log(this.secilen);
    }
    bulbakim(item) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingCtrl.create({
                message: 'gidiliyor',
                mode: 'ios',
            });
            loading.present();
            if (this.secilen == 'gönderilen') {
                for (let index = 0; index < this.onunolanlar.length; index++) {
                    if (this.onunolanlar[index].data.kargo_adi == this.onunkiler[item]) {
                        let navigationExtras = {
                            queryParams: {
                                toid: this.onunolanlar[index].user.from,
                                fromid: this.onunolanlar[index].user.to,
                                data: this.onunolanlar[index].data,
                                durum: 2,
                                id: this.onunolanlar[index].data.id,
                            },
                        };
                        this.navctrl.navigateRoot('chat', navigationExtras);
                        loading.dismiss();
                    }
                }
            }
            else if (this.secilen == 'mesajlarim') {
                for (let i = 0; i < this.benimolan.length; i++) {
                    if (this.benimolan[i].data.kargo_adi == this.benimolanlar[item]) {
                        let navigationExtras = {
                            queryParams: {
                                toid: this.benimolan[i].user.from,
                                fromid: this.benimolan[i].user.to,
                                data: this.benimolan[i].data,
                            },
                        };
                        this.navctrl.navigateRoot('chat', navigationExtras);
                        loading.dismiss();
                    }
                }
            }
        });
    }
    ionViewWillLeave() {
        this.loaded = false;
        this.benimlist = [];
        this.benimolanlar = [];
        this.onunkiler = [];
        this.onunlist = [];
    }
};
MesajlarPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_5__.AngularFirestore },
    { type: _services_profile_service__WEBPACK_IMPORTED_MODULE_2__.ProfileService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.ActivatedRoute },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.LoadingController }
];
MesajlarPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-mesajlar',
        template: _raw_loader_mesajlar_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_mesajlar_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], MesajlarPage);



/***/ }),

/***/ 4343:
/*!*********************************************!*\
  !*** ./src/app/mesajlar/mesajlar.page.scss ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtZXNhamxhci5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ 4063:
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/mesajlar/mesajlar.page.html ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>Mesajlar</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"close()\">Kapat </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-segment style=\"background: whitesmoke;\n  max-width: 95%;\n  margin: auto;\n  margin-top: 5%;\n  margin-bottom: 5%;\" mode=\"ios\" color=\"warning\" (ionChange)=\"tipsec($event)\" value=\"mesajlarim\">\n    <ion-segment-button value=\"gönderilen\">\n      <ion-label>Gönderilen</ion-label>\n    </ion-segment-button>\n    <ion-segment-button value=\"mesajlarim\">\n      <ion-label>Mesajlarım</ion-label>\n    </ion-segment-button>\n  </ion-segment>\n\n\n\n  <ion-list *ngIf=\"!loaded\">\n      <ion-item>\n          <ion-label>\n        <h3>\n          <ion-skeleton-text [animated]=\"true\" style=\"width: 80%;\"></ion-skeleton-text>\n        </h3>\n        <p>\n          <ion-skeleton-text [animated]=\"true\" style=\"width: 60%;\"></ion-skeleton-text>\n        </p>\n        <p>\n          <ion-skeleton-text [animated]=\"true\" style=\"width: 30%;\"></ion-skeleton-text>\n        </p>\n      </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-label>\n    <h3>\n      <ion-skeleton-text [animated]=\"true\" style=\"width: 80%;\"></ion-skeleton-text>\n    </h3>\n    <p>\n      <ion-skeleton-text [animated]=\"true\" style=\"width: 60%;\"></ion-skeleton-text>\n    </p>\n    <p>\n      <ion-skeleton-text [animated]=\"true\" style=\"width: 30%;\"></ion-skeleton-text>\n    </p>\n  </ion-label>\n</ion-item>\n<ion-item>\n  <ion-label>\n<h3>\n  <ion-skeleton-text [animated]=\"true\" style=\"width: 80%;\"></ion-skeleton-text>\n</h3>\n<p>\n  <ion-skeleton-text [animated]=\"true\" style=\"width: 60%;\"></ion-skeleton-text>\n</p>\n<p>\n  <ion-skeleton-text [animated]=\"true\" style=\"width: 30%;\"></ion-skeleton-text>\n</p>\n</ion-label>\n</ion-item>\n<ion-item>\n  <ion-label>\n<h3>\n  <ion-skeleton-text [animated]=\"true\" style=\"width: 80%;\"></ion-skeleton-text>\n</h3>\n<p>\n  <ion-skeleton-text [animated]=\"true\" style=\"width: 60%;\"></ion-skeleton-text>\n</p>\n<p>\n  <ion-skeleton-text [animated]=\"true\" style=\"width: 30%;\"></ion-skeleton-text>\n</p>\n</ion-label>\n</ion-item>\n  </ion-list>\n\n\n  <ion-list hidden={{mesajlarim}} >\n    <ion-item (click)=\"bulbakim(i)\" mode=\"ios\" *ngFor=\"let item of benimolanlar ; let i = index\" button>\n      <ion-label>\n        <p>{{item}}</p>\n      </ion-label>\n    </ion-item>\n  </ion-list>\n\n  <ion-list hidden={{gonderilen}} >\n    <ion-item (click)=\"bulbakim(i)\" mode=\"ios\" *ngFor=\"let item of onunkiler; let i = index\" button>\n      <ion-label>\n        <p>{{item}}</p>\n      </ion-label>\n    </ion-item>\n  </ion-list>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_mesajlar_mesajlar_module_ts.js.map