(self["webpackChunkselsmart"] = self["webpackChunkselsmart"] || []).push([["src_app_slider_slider_module_ts"],{

/***/ 7343:
/*!*************************************************!*\
  !*** ./src/app/slider/slider-routing.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SliderPageRoutingModule": () => (/* binding */ SliderPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _slider_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./slider.page */ 3480);




const routes = [
    {
        path: '',
        component: _slider_page__WEBPACK_IMPORTED_MODULE_0__.SliderPage
    }
];
let SliderPageRoutingModule = class SliderPageRoutingModule {
};
SliderPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SliderPageRoutingModule);



/***/ }),

/***/ 1105:
/*!*****************************************!*\
  !*** ./src/app/slider/slider.module.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SliderPageModule": () => (/* binding */ SliderPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 9122);
/* harmony import */ var _slider_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./slider-routing.module */ 7343);
/* harmony import */ var _slider_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./slider.page */ 3480);







let SliderPageModule = class SliderPageModule {
};
SliderPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _slider_routing_module__WEBPACK_IMPORTED_MODULE_0__.SliderPageRoutingModule
        ],
        declarations: [_slider_page__WEBPACK_IMPORTED_MODULE_1__.SliderPage]
    })
], SliderPageModule);



/***/ }),

/***/ 3480:
/*!***************************************!*\
  !*** ./src/app/slider/slider.page.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SliderPage": () => (/* binding */ SliderPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _raw_loader_slider_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./slider.page.html */ 5485);
/* harmony import */ var _slider_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./slider.page.scss */ 887);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 9122);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/storage-angular */ 1628);






let SliderPage = class SliderPage {
    constructor(navctrl, storage) {
        this.navctrl = navctrl;
        this.storage = storage;
    }
    ngOnInit() {
    }
    gec() {
        this.navctrl.navigateRoot("/home");
    }
    show(e) {
        console.log(e.detail.checked);
        this.storage.create();
        if (e.detail.checked == true) {
            this.storage.set("slidershow", true);
        }
        else if (e.detail.checked == false) {
            this.storage.set("slidershow", false);
        }
    }
    demo(event) {
        console.log(event);
    }
};
SliderPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.NavController },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_3__.Storage }
];
SliderPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-slider',
        template: _raw_loader_slider_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_slider_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], SliderPage);



/***/ }),

/***/ 887:
/*!*****************************************!*\
  !*** ./src/app/slider/slider.page.scss ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-slides {\n  height: 100%;\n}\n\n.swiper-slide {\n  display: block;\n}\n\n.swiper-slide h2 {\n  margin-top: 2.8rem;\n}\n\n.swiper-slide img {\n  max-height: 50%;\n  max-width: 80%;\n  margin: 60px 0 40px;\n  margin-top: 35%;\n  pointer-events: none;\n}\n\nb {\n  font-weight: 500;\n}\n\np {\n  padding: 0 40px;\n  font-size: 14px;\n  line-height: 1.5;\n  color: var(--ion-color-step-600, #60646b);\n}\n\np b {\n  color: var(--ion-text-color, #000000);\n}\n\n:root {\n  --ion-safe-area-top: 20px;\n  --ion-safe-area-bottom: 22px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNsaWRlci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxZQUFBO0FBQ0Y7O0FBRUE7RUFDRSxjQUFBO0FBQ0Y7O0FBRUE7RUFDRSxrQkFBQTtBQUNGOztBQUVBO0VBQ0UsZUFBQTtFQUNBLGNBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7RUFFQSxvQkFBQTtBQUFGOztBQUlBO0VBQ0UsZ0JBQUE7QUFERjs7QUFJQTtFQUNFLGVBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSx5Q0FBQTtBQURGOztBQUlBO0VBQ0UscUNBQUE7QUFERjs7QUFHQTtFQUNFLHlCQUFBO0VBQ0EsNEJBQUE7QUFBRiIsImZpbGUiOiJzbGlkZXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXNsaWRlcyB7XG4gIGhlaWdodDogMTAwJTtcbn1cblxuLnN3aXBlci1zbGlkZSB7XG4gIGRpc3BsYXk6IGJsb2NrO1xufVxuXG4uc3dpcGVyLXNsaWRlIGgyIHtcbiAgbWFyZ2luLXRvcDogMi44cmVtO1xufVxuXG4uc3dpcGVyLXNsaWRlIGltZyB7XG4gIG1heC1oZWlnaHQ6IDUwJTtcbiAgbWF4LXdpZHRoOiA4MCU7XG4gIG1hcmdpbjogNjBweCAwIDQwcHg7XG4gIG1hcmdpbi10b3A6IDM1JTtcblxuICBwb2ludGVyLWV2ZW50czogbm9uZTtcbn1cblxuXG5iIHtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbn1cblxucCB7XG4gIHBhZGRpbmc6IDAgNDBweDtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBsaW5lLWhlaWdodDogMS41O1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXN0ZXAtNjAwLCAjNjA2NDZiKTtcbn1cblxucCBiIHtcbiAgY29sb3I6IHZhcigtLWlvbi10ZXh0LWNvbG9yLCAjMDAwMDAwKTtcbn1cbjpyb290IHtcbiAgLS1pb24tc2FmZS1hcmVhLXRvcDogMjBweDtcbiAgLS1pb24tc2FmZS1hcmVhLWJvdHRvbTogMjJweDtcbn1cbiJdfQ== */");

/***/ }),

/***/ 5485:
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/slider/slider.page.html ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (" <ion-content fullscreen class=\"ion-padding\" scroll-y=\"false\">\n        <ion-slides pager=\"true\" (ionSlideDidChange)=\"demo($event)\">\n          <ion-slide>\n            <div class=\"slide\">\n              <img src=\"../../assets/img/1.svg\" />\n              <h2>Hoşgeldin</h2>\n              <p>\n                Hayatınızı kolaylaştıran akıllı ev cihazlarımızla tanışın! Evinizin her köşesini kontrol etmek ve enerji verimliliğini artırmak artık çok daha basit.\n              </p>\n            </div>\n          </ion-slide>\n\n          <ion-slide>\n            <img src=\"../../assets/img/2.svg\" />\n            <h2>Nedir SelSmart</h2>\n            <p>\n              Ev güvenliğinizi ön planda tutan akıllı cihazlarımızla huzurlu bir yaşam sizinle. Uzaktan izleme, hareket algılama ve acil durum bildirimleri sayesinde evinizin kontrolü her zaman avucunuzun içinde.\n            </p>\n          </ion-slide>\n\n          <ion-slide>\n            <img src=\"../../assets/img/3.svg\" />\n            <h2>Akıllı Ev, Akıllı Yaşam</h2>\n            <p>\n              Sadece bir dokunuşla evinizi kendiniz için çalışan bir organizmaya dönüştürün. Enerji tasarruflu aydınlatma, otomatik perde kontrolü ve kişisel asistanımızla yaşam kalitenizi yükseltin.\n            </p>\n          </ion-slide>\n\n          <ion-slide>\n            <img src=\"../../assets/img/4.svg\" />\n            <h2>Başlamaya Hazır Mısın?</h2>\n            <ion-item style=\"    width: 70%;\n            margin: auto;\" lines=\"none\">\n              <ion-checkbox (ionChange)=\"show($event)\" slot=\"start\"></ion-checkbox>\n              <ion-label>Bir daha gösterme</ion-label>\n            </ion-item>\n            <ion-button (click)=\"gec()\" fill=\"clear\">Başlayalım <ion-icon slot=\"end\" name=\"arrow-forward\"></ion-icon></ion-button>\n          </ion-slide>\n        </ion-slides>\n      </ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_slider_slider_module_ts.js.map