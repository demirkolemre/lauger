(self["webpackChunkselsmart"] = self["webpackChunkselsmart"] || []).push([["main"],{

/***/ 8255:
/*!*******************************************************!*\
  !*** ./$_lazy_route_resources/ lazy namespace object ***!
  \*******************************************************/
/***/ ((module) => {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(() => {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = () => ([]);
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = 8255;
module.exports = webpackEmptyAsyncContext;

/***/ }),

/***/ 158:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _services_auth_guard__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./services/auth.guard */ 8063);




const routes = [
    {
        path: '',
        redirectTo: 'splash',
        pathMatch: 'full'
    },
    {
        path: 'home',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_home_home_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./home/home.module */ 3467)).then(m => m.HomePageModule),
        canActivate: [_services_auth_guard__WEBPACK_IMPORTED_MODULE_0__.AuthGuard]
    },
    {
        path: 'login',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_login_login_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./login/login.module */ 107)).then(m => m.LoginPageModule)
    },
    {
        path: 'register',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_register_register_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./register/register.module */ 8723)).then(m => m.RegisterPageModule)
    },
    {
        path: 'reset-password',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_reset-password_reset-password_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./reset-password/reset-password.module */ 4371)).then(m => m.ResetPasswordPageModule)
    },
    {
        path: 'profile',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_profile_profile_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./profile/profile.module */ 4523)).then(m => m.ProfilePageModule),
        canActivate: [_services_auth_guard__WEBPACK_IMPORTED_MODULE_0__.AuthGuard]
    },
    {
        path: 'splash',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_splash_splash_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./splash/splash.module */ 9623)).then(m => m.SplashPageModule)
    },
    {
        path: 'tab2',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_tab2_tab2_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./tab2/tab2.module */ 7008)).then(m => m.Tab2PageModule),
        canActivate: [_services_auth_guard__WEBPACK_IMPORTED_MODULE_0__.AuthGuard]
    },
    {
        path: 'chat',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_chat_chat_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./chat/chat.module */ 818)).then(m => m.ChatPageModule)
    },
    {
        path: 'mesajlar',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_mesajlar_mesajlar_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./mesajlar/mesajlar.module */ 4910)).then(m => m.MesajlarPageModule)
    },
    {
        path: 'demo',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_demo_demo_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./demo/demo.module */ 849)).then(m => m.DemoPageModule)
    },
    {
        path: 'slider',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_slider_slider_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./slider/slider.module */ 1105)).then(m => m.SliderPageModule)
    },
    {
        path: 'demos',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_demos_demos_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./demos/demos.module */ 9242)).then(m => m.DemosPageModule)
    },
    {
        path: 'rutins',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_rutins_rutins_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./rutins/rutins.module */ 322)).then(m => m.RutinsPageModule)
    },
    {
        path: 'blue',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_blue_blue_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./blue/blue.module */ 3634)).then(m => m.BluePageModule)
    },
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_3__.PreloadAllModules })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], AppRoutingModule);



/***/ }),

/***/ 5041:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./app.component.html */ 1106);
/* harmony import */ var _app_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component.scss */ 3069);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);




let AppComponent = class AppComponent {
    constructor() {
        this.appPages = [
            { title: 'Ana Sayfa', url: '/home', icon: 'home' },
            { title: 'Profil', url: '/profile', icon: 'person' },
        ];
    }
};
AppComponent.ctorParameters = () => [];
AppComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-root',
        template: _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_app_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AppComponent);



/***/ }),

/***/ 6747:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/platform-browser */ 9075);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 9122);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.component */ 5041);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app-routing.module */ 158);
/* harmony import */ var _components_card_card_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/card/card.component */ 3117);
/* harmony import */ var _components_devicedit_devicedit_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/devicedit/devicedit.component */ 4518);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/fire/auth */ 9743);
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/fire/firestore */ 6717);
/* harmony import */ var _angular_fire_auth_guard__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/fire/auth-guard */ 8386);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/environments/environment */ 2340);
/* harmony import */ var _angular_fire__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/fire */ 57);
/* harmony import */ var _angular_fire_database__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/fire/database */ 4134);
/* harmony import */ var _angular_service_worker__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/service-worker */ 2249);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic/storage-angular */ 4925);



















let AppModule = class AppModule {
};
AppModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent, _components_card_card_component__WEBPACK_IMPORTED_MODULE_2__.CardComponent, _components_devicedit_devicedit_component__WEBPACK_IMPORTED_MODULE_3__.DeviceditComponent],
        imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__.BrowserModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule.forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_1__.AppRoutingModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_9__.HttpClientModule,
            _angular_fire__WEBPACK_IMPORTED_MODULE_10__.AngularFireModule.initializeApp(src_environments_environment__WEBPACK_IMPORTED_MODULE_4__.environment.firebase),
            _angular_fire_auth__WEBPACK_IMPORTED_MODULE_11__.AngularFireAuthModule,
            _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_12__.AngularFirestoreModule,
            _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_13__.IonicStorageModule.forRoot(),
            _angular_fire_database__WEBPACK_IMPORTED_MODULE_14__.AngularFireDatabaseModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_15__.FormsModule,
            _angular_service_worker__WEBPACK_IMPORTED_MODULE_16__.ServiceWorkerModule.register('ngsw-worker.js', {
                enabled: src_environments_environment__WEBPACK_IMPORTED_MODULE_4__.environment.production,
                // Register the ServiceWorker as soon as the app is stable
                // or after 30 seconds (whichever comes first).
                registrationStrategy: 'registerWhenStable:30000'
            }),
        ],
        providers: [{ provide: _angular_router__WEBPACK_IMPORTED_MODULE_17__.RouteReuseStrategy, useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicRouteStrategy },
            _angular_fire_auth_guard__WEBPACK_IMPORTED_MODULE_18__.AngularFireAuthGuard, _angular_fire__WEBPACK_IMPORTED_MODULE_10__.AngularFireModule],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent],
    })
], AppModule);



/***/ }),

/***/ 3117:
/*!***************************************************!*\
  !*** ./src/app/components/card/card.component.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CardComponent": () => (/* binding */ CardComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _raw_loader_card_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./card.component.html */ 9064);
/* harmony import */ var _card_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./card.component.scss */ 5310);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_fire_database__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/fire/database */ 4134);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 9122);






let CardComponent = class CardComponent {
    constructor(modalCtrl, realbd, alertctrl, toastController) {
        this.modalCtrl = modalCtrl;
        this.realbd = realbd;
        this.alertctrl = alertctrl;
        this.toastController = toastController;
    }
    ngOnInit() {
        // Her bir s değerini başlangıçta kapalı olarak ayarla
        this.initializeSValues();
    }
    initializeSValues() {
        if (this.data && this.data.data) {
            Object.keys(this.data.data).forEach(sensorKey => {
                const sensor = this.data.data[sensorKey];
                Object.keys(sensor).forEach(sKey => {
                });
            });
        }
    }
    confirm() {
        return this.modalCtrl.dismiss("a", 'confirm');
    }
    edit(e) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertctrl.create({
                header: 'Yeni adı giriniz',
                buttons: [{
                        text: 'Tamam',
                        handler: (alertData) => {
                            console.log(alertData.name1);
                            if (alertData.name1.length > 2) {
                                this.updatename(e, alertData.name1);
                            }
                        }
                    }],
                inputs: [
                    {
                        name: "name1",
                        placeholder: "Yeni isim",
                        attributes: {
                            maxlength: 8,
                        },
                    },
                ],
            });
            yield alert.present();
        });
    }
    updatename(veri, isim) {
        console.log("veri = ");
        console.log(veri);
        console.log("yenisim = " + isim);
        this.realbd.database.ref("/dev/" + this.data.key + "/node/" + veri).update({
            name: isim
        }).then(r => {
            this.tomesaj("İsim güncellendi");
        });
    }
    getSensorKeys() {
        if (this.data && this.data.data) {
            return Object.keys(this.data.data);
        }
        return [];
    }
    getSKeys(sensorData) {
        if (sensorData) {
            return Object.keys(sensorData).filter(key => key.startsWith('s'));
        }
        return [];
    }
    toggleChanged(sensorData, sKey) {
        console.log(`Toggle for ${sKey} changed:`, sensorData[sKey]);
        // Burada toggle durumu değiştiğinde yapılacak işlemleri gerçekleştirebilirsiniz
    }
    getSensorValues(sensorKey) {
        return this.data.data[sensorKey];
    }
    tomesaj(mesaj) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: mesaj,
                duration: 3000,
                cssClass: 'custom-toast',
            });
            yield toast.present();
        });
    }
};
CardComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ModalController },
    { type: _angular_fire_database__WEBPACK_IMPORTED_MODULE_4__.AngularFireDatabase },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ToastController }
];
CardComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-card',
        template: _raw_loader_card_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_card_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], CardComponent);



/***/ }),

/***/ 4518:
/*!*************************************************************!*\
  !*** ./src/app/components/devicedit/devicedit.component.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeviceditComponent": () => (/* binding */ DeviceditComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _raw_loader_devicedit_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./devicedit.component.html */ 8848);
/* harmony import */ var _devicedit_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./devicedit.component.scss */ 4595);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_fire_database__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/fire/database */ 4134);
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/fire/firestore */ 6717);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 9122);
/* harmony import */ var src_app_services_profile_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/profile.service */ 7715);








let DeviceditComponent = class DeviceditComponent {
    constructor(modalCtrl, realbd, alertctrl, toastController, profilservice, firestore) {
        this.modalCtrl = modalCtrl;
        this.realbd = realbd;
        this.alertctrl = alertctrl;
        this.toastController = toastController;
        this.profilservice = profilservice;
        this.firestore = firestore;
        this.edit = false;
        this.cihazlar = [];
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.cihazlar = this.data.devices;
        console.log(this.cihazlar);
        console.log(this.profilid);
        console.log(this.data.id);
    }
    confirm() {
        return this.modalCtrl.dismiss("a", 'confirm');
    }
    updatedevname(dev) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            console.log(dev);
            const alert = yield this.alertctrl.create({
                header: 'Yeni adı giriniz',
                buttons: [
                    {
                        text: 'Tamam',
                        handler: (alertData) => {
                            //takes the data
                            console.log(alertData.name1);
                            if (alertData.name1.length > 2) {
                                this.firestore.collection("/kullanicilar/").doc(this.profilid).collection("/hotkeys/").doc(this.data.id).update({
                                    name: alertData.name1
                                }).then(() => {
                                    this.modalCtrl.dismiss();
                                });
                            }
                        },
                    },
                ],
                inputs: [
                    {
                        name: 'name1',
                        placeholder: dev.name,
                        attributes: {
                            maxlength: 8,
                        },
                    },
                ],
            });
            yield alert.present();
        });
    }
    tomesaj(mesaj) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: mesaj,
                duration: 3000,
                cssClass: 'custom-toast',
            });
            yield toast.present();
        });
    }
    editdev() {
        this.edit = !this.edit;
    }
    deldev(dev) {
        console.log(dev);
        this.cihazlar.forEach((element, index) => {
            if (element == dev)
                this.cihazlar.splice(index, 1);
        });
        this.firestore.collection("/kullanicilar/").doc(this.profilid).collection("/hotkeys/").doc(this.data.id).update({
            devices: this.cihazlar
        });
        console.log(this.cihazlar);
    }
};
DeviceditComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController },
    { type: _angular_fire_database__WEBPACK_IMPORTED_MODULE_5__.AngularFireDatabase },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ToastController },
    { type: src_app_services_profile_service__WEBPACK_IMPORTED_MODULE_2__.ProfileService },
    { type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_6__.AngularFirestore }
];
DeviceditComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-devicedit',
        template: _raw_loader_devicedit_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_devicedit_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], DeviceditComponent);



/***/ }),

/***/ 8063:
/*!****************************************!*\
  !*** ./src/app/services/auth.guard.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthGuard": () => (/* binding */ AuthGuard)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./auth.service */ 7556);




let AuthGuard = class AuthGuard {
    constructor(authService, router) {
        this.authService = authService;
        this.router = router;
    }
    canActivate(next, state) {
        return new Promise((resolve, reject) => (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__awaiter)(this, void 0, void 0, function* () {
            try {
                const user = yield this.authService.getUser();
                if (user) {
                    resolve(true);
                }
                else {
                    reject('No user logged in');
                    this.router.navigateByUrl('/login');
                }
            }
            catch (error) {
                reject(error);
            }
        }));
    }
};
AuthGuard.ctorParameters = () => [
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
AuthGuard = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], AuthGuard);



/***/ }),

/***/ 7556:
/*!******************************************!*\
  !*** ./src/app/services/auth.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthService": () => (/* binding */ AuthService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/fire/auth */ 9743);
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/fire/firestore */ 6717);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ 8049);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! firebase/firestore */ 2491);






let AuthService = class AuthService {
    constructor(afAuth, firestore) {
        this.afAuth = afAuth;
        this.firestore = firestore;
    }
    getUser() {
        return this.afAuth.authState.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.first)()).toPromise();
    }
    login(email, password) {
        return this.afAuth.signInWithEmailAndPassword(email, password);
    }
    signup(email, password, name, surname, number) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            try {
                var kayit = {
                    "email": email,
                    "name": name,
                    "surname": surname,
                    "number": number,
                    "isOnline": "false"
                };
                const newUserCredential = yield this.afAuth.createUserWithEmailAndPassword(email, password);
                yield this.firestore
                    .doc(`kullanicilar/${newUserCredential.user.uid}`)
                    .set(kayit);
                return newUserCredential;
            }
            catch (error) {
                throw error;
            }
        });
    }
    resetPassword(email) {
        return this.afAuth.sendPasswordResetEmail(email);
    }
    logout() {
        return this.afAuth.signOut();
    }
};
AuthService.ctorParameters = () => [
    { type: _angular_fire_auth__WEBPACK_IMPORTED_MODULE_3__.AngularFireAuth },
    { type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_4__.AngularFirestore }
];
AuthService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Injectable)({
        providedIn: 'root'
    })
], AuthService);



/***/ }),

/***/ 7715:
/*!*********************************************!*\
  !*** ./src/app/services/profile.service.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfileService": () => (/* binding */ ProfileService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/fire/firestore */ 6717);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./auth.service */ 7556);
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! firebase/app */ 2329);
/* harmony import */ var firebase_auth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! firebase/auth */ 1952);






let ProfileService = class ProfileService {
    constructor(firestore, authService) {
        this.firestore = firestore;
        this.authService = authService;
    }
    getUserProfile() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const user = yield this.authService.getUser();
            this.currentUser = user;
            this.useridsi = user.uid;
            this.userProfile = this.firestore.doc(`kullanicilar/${user.uid}`);
            return this.userProfile.valueChanges();
        });
    }
    updateName(name) {
        return this.userProfile.update({ name });
    }
    updateSurname(surname) {
        return this.userProfile.update({ surname });
    }
    updateEmail(newEmail, password) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const credential = firebase_app__WEBPACK_IMPORTED_MODULE_1__.default.auth.EmailAuthProvider.credential(this.currentUser.email, password);
            try {
                yield this.currentUser.reauthenticateWithCredential(credential);
                yield this.currentUser.updateEmail(newEmail);
                return this.userProfile.update({ email: newEmail });
            }
            catch (error) {
                console.error(error);
            }
        });
    }
    updatePassword(newPassword, oldPassword) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const credential = firebase_app__WEBPACK_IMPORTED_MODULE_1__.default.auth.EmailAuthProvider.credential(this.currentUser.email, oldPassword);
            try {
                yield this.currentUser.reauthenticateWithCredential(credential);
                return this.currentUser.updatePassword(newPassword);
            }
            catch (error) {
                console.error(error);
            }
        });
    }
};
ProfileService.ctorParameters = () => [
    { type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_4__.AngularFirestore },
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService }
];
ProfileService = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Injectable)({
        providedIn: 'root'
    })
], ProfileService);



/***/ }),

/***/ 2340:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": () => (/* binding */ environment)
/* harmony export */ });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false,
    firebase: {
        apiKey: "AIzaSyAhkxAfL66iLfNBaYhaYT03Q7Ux98ZL5yQ",
        authDomain: "chat-app-btbs.firebaseapp.com",
        projectId: "chat-app-btbs",
        storageBucket: "chat-app-btbs.appspot.com",
        messagingSenderId: "568380153576",
        appId: "1:568380153576:web:b2b8df190452f76d0c335d",
        measurementId: "G-XRLXNN5T5X"
    }
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ 4431:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ 4608);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 6747);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 2340);




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
}
(0,_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__.platformBrowserDynamic)().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule)
    .catch(err => console.log(err));


/***/ }),

/***/ 863:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/ lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \******************************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./ion-accordion_2.entry.js": [
		8359,
		"common",
		"node_modules_ionic_core_dist_esm_ion-accordion_2_entry_js"
	],
	"./ion-action-sheet.entry.js": [
		7321,
		"common",
		"node_modules_ionic_core_dist_esm_ion-action-sheet_entry_js"
	],
	"./ion-alert.entry.js": [
		6108,
		"common",
		"node_modules_ionic_core_dist_esm_ion-alert_entry_js"
	],
	"./ion-app_8.entry.js": [
		1489,
		"common",
		"node_modules_ionic_core_dist_esm_ion-app_8_entry_js"
	],
	"./ion-avatar_3.entry.js": [
		305,
		"node_modules_ionic_core_dist_esm_ion-avatar_3_entry_js"
	],
	"./ion-back-button.entry.js": [
		5830,
		"common",
		"node_modules_ionic_core_dist_esm_ion-back-button_entry_js"
	],
	"./ion-backdrop.entry.js": [
		3519,
		"node_modules_ionic_core_dist_esm_ion-backdrop_entry_js"
	],
	"./ion-breadcrumb_2.entry.js": [
		4355,
		"common",
		"node_modules_ionic_core_dist_esm_ion-breadcrumb_2_entry_js"
	],
	"./ion-button_2.entry.js": [
		392,
		"node_modules_ionic_core_dist_esm_ion-button_2_entry_js"
	],
	"./ion-card_5.entry.js": [
		6911,
		"node_modules_ionic_core_dist_esm_ion-card_5_entry_js"
	],
	"./ion-checkbox.entry.js": [
		937,
		"node_modules_ionic_core_dist_esm_ion-checkbox_entry_js"
	],
	"./ion-chip.entry.js": [
		8695,
		"node_modules_ionic_core_dist_esm_ion-chip_entry_js"
	],
	"./ion-col_3.entry.js": [
		2239,
		"node_modules_ionic_core_dist_esm_ion-col_3_entry_js"
	],
	"./ion-datetime-button.entry.js": [
		1135,
		"default-node_modules_ionic_core_dist_esm_data-caf38df0_js-node_modules_ionic_core_dist_esm_th-3ec348",
		"node_modules_ionic_core_dist_esm_ion-datetime-button_entry_js"
	],
	"./ion-datetime_3.entry.js": [
		8837,
		"default-node_modules_ionic_core_dist_esm_data-caf38df0_js-node_modules_ionic_core_dist_esm_th-3ec348",
		"common",
		"node_modules_ionic_core_dist_esm_ion-datetime_3_entry_js"
	],
	"./ion-fab_3.entry.js": [
		4195,
		"common",
		"node_modules_ionic_core_dist_esm_ion-fab_3_entry_js"
	],
	"./ion-img.entry.js": [
		1709,
		"node_modules_ionic_core_dist_esm_ion-img_entry_js"
	],
	"./ion-infinite-scroll_2.entry.js": [
		3087,
		"common",
		"node_modules_ionic_core_dist_esm_ion-infinite-scroll_2_entry_js"
	],
	"./ion-input.entry.js": [
		4513,
		"common",
		"node_modules_ionic_core_dist_esm_ion-input_entry_js"
	],
	"./ion-item-option_3.entry.js": [
		8056,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item-option_3_entry_js"
	],
	"./ion-item_8.entry.js": [
		862,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item_8_entry_js"
	],
	"./ion-loading.entry.js": [
		7509,
		"node_modules_ionic_core_dist_esm_ion-loading_entry_js"
	],
	"./ion-menu_3.entry.js": [
		6272,
		"common",
		"node_modules_ionic_core_dist_esm_ion-menu_3_entry_js"
	],
	"./ion-modal.entry.js": [
		1855,
		"common",
		"node_modules_ionic_core_dist_esm_ion-modal_entry_js"
	],
	"./ion-nav_2.entry.js": [
		8708,
		"common",
		"node_modules_ionic_core_dist_esm_ion-nav_2_entry_js"
	],
	"./ion-picker-column-internal.entry.js": [
		1349,
		"common",
		"node_modules_ionic_core_dist_esm_ion-picker-column-internal_entry_js"
	],
	"./ion-picker-internal.entry.js": [
		7915,
		"node_modules_ionic_core_dist_esm_ion-picker-internal_entry_js"
	],
	"./ion-popover.entry.js": [
		3527,
		"common",
		"node_modules_ionic_core_dist_esm_ion-popover_entry_js"
	],
	"./ion-progress-bar.entry.js": [
		4694,
		"node_modules_ionic_core_dist_esm_ion-progress-bar_entry_js"
	],
	"./ion-radio_2.entry.js": [
		9222,
		"node_modules_ionic_core_dist_esm_ion-radio_2_entry_js"
	],
	"./ion-range.entry.js": [
		5277,
		"common",
		"node_modules_ionic_core_dist_esm_ion-range_entry_js"
	],
	"./ion-refresher_2.entry.js": [
		9921,
		"common",
		"node_modules_ionic_core_dist_esm_ion-refresher_2_entry_js"
	],
	"./ion-reorder_2.entry.js": [
		3122,
		"common",
		"node_modules_ionic_core_dist_esm_ion-reorder_2_entry_js"
	],
	"./ion-ripple-effect.entry.js": [
		1602,
		"node_modules_ionic_core_dist_esm_ion-ripple-effect_entry_js"
	],
	"./ion-route_4.entry.js": [
		5174,
		"node_modules_ionic_core_dist_esm_ion-route_4_entry_js"
	],
	"./ion-searchbar.entry.js": [
		7895,
		"common",
		"node_modules_ionic_core_dist_esm_ion-searchbar_entry_js"
	],
	"./ion-segment_2.entry.js": [
		6164,
		"common",
		"node_modules_ionic_core_dist_esm_ion-segment_2_entry_js"
	],
	"./ion-select_3.entry.js": [
		592,
		"node_modules_ionic_core_dist_esm_ion-select_3_entry_js"
	],
	"./ion-slide_2.entry.js": [
		7162,
		"node_modules_ionic_core_dist_esm_ion-slide_2_entry_js"
	],
	"./ion-spinner.entry.js": [
		1374,
		"common",
		"node_modules_ionic_core_dist_esm_ion-spinner_entry_js"
	],
	"./ion-split-pane.entry.js": [
		7896,
		"node_modules_ionic_core_dist_esm_ion-split-pane_entry_js"
	],
	"./ion-tab-bar_2.entry.js": [
		5043,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab-bar_2_entry_js"
	],
	"./ion-tab_2.entry.js": [
		7802,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab_2_entry_js"
	],
	"./ion-text.entry.js": [
		9072,
		"node_modules_ionic_core_dist_esm_ion-text_entry_js"
	],
	"./ion-textarea.entry.js": [
		2191,
		"node_modules_ionic_core_dist_esm_ion-textarea_entry_js"
	],
	"./ion-toast.entry.js": [
		801,
		"node_modules_ionic_core_dist_esm_ion-toast_entry_js"
	],
	"./ion-toggle.entry.js": [
		7110,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toggle_entry_js"
	],
	"./ion-virtual-scroll.entry.js": [
		431,
		"node_modules_ionic_core_dist_esm_ion-virtual-scroll_entry_js"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(() => {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = 863;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 3069:
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhcHAuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ 5310:
/*!*****************************************************!*\
  !*** ./src/app/components/card/card.component.scss ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjYXJkLmNvbXBvbmVudC5zY3NzIn0= */");

/***/ }),

/***/ 4595:
/*!***************************************************************!*\
  !*** ./src/app/components/devicedit/devicedit.component.scss ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkZXZpY2VkaXQuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ 1106:
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-app>\n\n    <ion-router-outlet style=\"background: black;\" id=\"main-content\"></ion-router-outlet>\n</ion-app>\n");

/***/ }),

/***/ 9064:
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/card/card.component.html ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-toolbar>\n  <ion-row>\n    <ion-col\n      ><ion-label>{{ data.key }}</ion-label></ion-col\n    >\n\n    <ion-col style=\"text-align: end\">\n      <ion-button fill=\"clear\" (click)=\"confirm()\">Kapat</ion-button>\n    </ion-col>\n  </ion-row>\n</ion-toolbar>\n\n<ion-content>\n\n  <ion-list >\n    <ion-card  *ngFor=\"let sensorKey of getSensorKeys()\">\n      <ion-item>\n        <h1 style=\"margin: 3%;\">{{ getSensorValues(sensorKey).name }}</h1>\n        <ion-icon name=\"pencil\" (click)=\"edit(sensorKey)\" slot=\"end\"></ion-icon>\n      </ion-item>\n      <ion-item *ngFor=\"let sKey of getSKeys(getSensorValues(sensorKey))\">\n        <ion-label>{{ sKey }}</ion-label>\n        <ion-toggle\n        mode=\"ios\"\n        [(ngModel)]=\"getSensorValues(sensorKey)[sKey]\"\n        (ionChange)=\"toggleChanged(getSensorValues(sensorKey), sKey)\"\n        ></ion-toggle>\n      </ion-item>\n    </ion-card>\n  </ion-list>\n</ion-content>\n\n<!--\n<ion-content class=\"ion-padding\">\n  <ion-card class=\"cardo\">\n    <ion-label> Tekli Cihaz</ion-label>\n    <ion-item>\n      <ion-label>s1</ion-label>\n      <ion-toggle mode=\"ios\"></ion-toggle>\n    </ion-item>\n  </ion-card>\n\n  <ion-card>\n    <ion-label>2'li cihaz</ion-label>\n    <ion-grid>\n      <ion-row>\n        <ion-col>\n          <ion-card class=\"cardo\">\n            <ion-card-title style=\"text-align: center\">s1</ion-card-title>\n            <ion-card-content>\n              <ion-toggle mode=\"ios\"></ion-toggle\n            ></ion-card-content>\n          </ion-card>\n        </ion-col>\n\n        <ion-col>\n          <ion-card class=\"cardo\">\n            <ion-card-title style=\"text-align: center\">s2</ion-card-title>\n            <ion-card-content>\n              <ion-toggle mode=\"ios\"></ion-toggle\n            ></ion-card-content>\n          </ion-card>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-card>\n\n\n\n  <ion-card >\n    <ion-label>4'lü cihaz</ion-label>\n    <ion-grid>\n      <ion-row>\n        <ion-col>\n          <ion-card class=\"cardo\">\n            <ion-card-title style=\"text-align: center\">s1</ion-card-title>\n            <ion-card-content>\n              <ion-toggle mode=\"ios\"></ion-toggle\n            ></ion-card-content>\n          </ion-card>\n        </ion-col>\n\n        <ion-col>\n          <ion-card class=\"cardo\">\n            <ion-card-title style=\"text-align: center\">s2</ion-card-title>\n            <ion-card-content>\n              <ion-toggle mode=\"ios\"></ion-toggle\n            ></ion-card-content>\n          </ion-card>\n        </ion-col>\n      </ion-row>\n\n      <ion-row>\n        <ion-col>\n          <ion-card class=\"cardo\">\n            <ion-card-title style=\"text-align: center\">s3</ion-card-title>\n            <ion-card-content>\n              <ion-toggle mode=\"ios\"></ion-toggle\n            ></ion-card-content>\n          </ion-card>\n        </ion-col>\n\n        <ion-col>\n          <ion-card class=\"cardo\">\n            <ion-card-title style=\"text-align: center\">s4</ion-card-title>\n            <ion-card-content>\n              <ion-toggle mode=\"ios\"></ion-toggle\n            ></ion-card-content>\n          </ion-card>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </ion-card>\n\n\n\n\n<ion-card >\n  <ion-label> 8'li Cihaz</ion-label>\n    <ion-item>\n      <ion-label>s1</ion-label>\n      <ion-toggle mode=\"ios\"></ion-toggle>\n    </ion-item>\n\n    <ion-item>\n      <ion-label>s2</ion-label>\n      <ion-toggle mode=\"ios\"></ion-toggle>\n    </ion-item>\n\n    <ion-item>\n      <ion-label>s3</ion-label>\n      <ion-toggle mode=\"ios\"></ion-toggle>\n    </ion-item>\n\n    <ion-item>\n      <ion-label>s4</ion-label>\n      <ion-toggle mode=\"ios\"></ion-toggle>\n    </ion-item>\n\n    <ion-item>\n      <ion-label>s5</ion-label>\n      <ion-toggle mode=\"ios\"></ion-toggle>\n    </ion-item>\n\n    <ion-item>\n      <ion-label>s6</ion-label>\n      <ion-toggle mode=\"ios\"></ion-toggle>\n    </ion-item>\n\n    <ion-item>\n      <ion-label>s7</ion-label>\n      <ion-toggle mode=\"ios\"></ion-toggle>\n    </ion-item>\n\n    <ion-item>\n      <ion-label>s8</ion-label>\n      <ion-toggle mode=\"ios\"></ion-toggle>\n    </ion-item>\n</ion-card>\n\n\n\n\n\n\n\n<ion-card >\n  <ion-label> 16'lı Cihaz</ion-label>\n    <ion-item>\n      <ion-label>s1</ion-label>\n      <ion-toggle mode=\"ios\"></ion-toggle>\n    </ion-item>\n\n    <ion-item>\n      <ion-label>s2</ion-label>\n      <ion-toggle mode=\"ios\"></ion-toggle>\n    </ion-item>\n\n    <ion-item>\n      <ion-label>s3</ion-label>\n      <ion-toggle mode=\"ios\"></ion-toggle>\n    </ion-item>\n\n    <ion-item>\n      <ion-label>s4</ion-label>\n      <ion-toggle mode=\"ios\"></ion-toggle>\n    </ion-item>\n\n    <ion-item>\n      <ion-label>s5</ion-label>\n      <ion-toggle mode=\"ios\"></ion-toggle>\n    </ion-item>\n\n    <ion-item>\n      <ion-label>s6</ion-label>\n      <ion-toggle mode=\"ios\"></ion-toggle>\n    </ion-item>\n\n    <ion-item>\n      <ion-label>s7</ion-label>\n      <ion-toggle mode=\"ios\"></ion-toggle>\n    </ion-item>\n\n    <ion-item>\n      <ion-label>s8</ion-label>\n      <ion-toggle mode=\"ios\"></ion-toggle>\n    </ion-item>\n\n    <ion-item>\n      <ion-label>s9</ion-label>\n      <ion-toggle mode=\"ios\"></ion-toggle>\n    </ion-item>\n\n    <ion-item>\n      <ion-label>s10</ion-label>\n      <ion-toggle mode=\"ios\"></ion-toggle>\n    </ion-item>\n\n    <ion-item>\n      <ion-label>s11</ion-label>\n      <ion-toggle mode=\"ios\"></ion-toggle>\n    </ion-item>\n\n    <ion-item>\n      <ion-label>s12</ion-label>\n      <ion-toggle mode=\"ios\"></ion-toggle>\n    </ion-item>\n\n    <ion-item>\n      <ion-label>s13</ion-label>\n      <ion-toggle mode=\"ios\"></ion-toggle>\n    </ion-item>\n\n    <ion-item>\n      <ion-label>s14</ion-label>\n      <ion-toggle mode=\"ios\"></ion-toggle>\n    </ion-item>\n\n    <ion-item>\n      <ion-label>s15</ion-label>\n      <ion-toggle mode=\"ios\"></ion-toggle>\n    </ion-item>\n\n    <ion-item>\n      <ion-label>s16</ion-label>\n      <ion-toggle mode=\"ios\"></ion-toggle>\n    </ion-item>\n\n\n</ion-card>\n</ion-content>\n-->\n");

/***/ }),

/***/ 8848:
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/devicedit/devicedit.component.html ***!
  \*****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n<ion-content>\n  <ion-list style=\"margin: 5%;\">\n    <h1 style=\"text-align: center;\">{{data.name}}         <ion-icon (click)=\"updatedevname(data)\" style=\"position: absolute; color: gray;\" *ngIf=\"edit\" slot=\"end\" name=\"brush\"></ion-icon>\n    </h1>\n      <ion-item *ngFor=\"let dev of cihazlar\">\n        <ion-label>{{dev.data.name}}</ion-label>\n        <ion-icon *ngIf=\"edit\" slot=\"end\" name=\"close-circle\" (click)=\"deldev(dev)\"  ></ion-icon>\n      </ion-item>\n\n\n      <ion-row style=\"width: 100%;\">\n        <ion-col>\n          <ion-button shape=\"round\" expand=\"block\" color=\"danger\">Sil</ion-button>\n\n        </ion-col>\n\n        <ion-col>\n          <ion-button (click)=\"editdev()\" shape=\"round\" expand=\"block\" color=\"warning\">Düzenle</ion-button>\n\n        </ion-col>\n      </ion-row>\n  </ion-list>\n</ion-content>\n");

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ "use strict";
/******/ 
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(4431)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map