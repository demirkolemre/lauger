(self["webpackChunkselsmart"] = self["webpackChunkselsmart"] || []).push([["src_app_profile_profile_module_ts"],{

/***/ 4523:
/*!*******************************************!*\
  !*** ./src/app/profile/profile.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfilePageModule": () => (/* binding */ ProfilePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 9122);
/* harmony import */ var _profile_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./profile.page */ 2919);







const routes = [
    {
        path: '',
        component: _profile_page__WEBPACK_IMPORTED_MODULE_0__.ProfilePage
    }
];
let ProfilePageModule = class ProfilePageModule {
};
ProfilePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule,
            _angular_router__WEBPACK_IMPORTED_MODULE_6__.RouterModule.forChild(routes)
        ],
        declarations: [_profile_page__WEBPACK_IMPORTED_MODULE_0__.ProfilePage]
    })
], ProfilePageModule);



/***/ }),

/***/ 2919:
/*!*****************************************!*\
  !*** ./src/app/profile/profile.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfilePage": () => (/* binding */ ProfilePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _raw_loader_profile_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./profile.page.html */ 2907);
/* harmony import */ var _profile_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./profile.page.scss */ 231);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/auth.service */ 7556);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var src_app_services_profile_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/profile.service */ 7715);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 9122);









let ProfilePage = class ProfilePage {
    constructor(authService, router, profileService, alertCtrl, navctrl) {
        this.authService = authService;
        this.router = router;
        this.profileService = profileService;
        this.alertCtrl = alertCtrl;
        this.navctrl = navctrl;
    }
    ionViewWillEnter() {
        this.profileService.getUserProfile().then(profile$ => {
            profile$.subscribe(userProfile => {
                this.userProfile = userProfile;
                console.log(this.profileService.useridsi);
            });
        });
    }
    logOut() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            yield this.authService.logout();
            this.router.navigateByUrl('/login');
        });
    }
    updateName() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                subHeader: 'İsminiz',
                cssClass: 'custom-alert',
                inputs: [
                    {
                        type: 'text',
                        name: 'name',
                        placeholder: 'İsminiz',
                        value: this.userProfile.name
                    }
                ],
                buttons: [
                    { text: 'Cancel' },
                    {
                        text: 'Save',
                        handler: data => {
                            this.profileService.updateName(data.name);
                        }
                    }
                ]
            });
            return yield alert.present();
        });
    }
    updateSurname() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                subHeader: 'Soyisminiz',
                cssClass: 'custom-alert',
                inputs: [
                    {
                        type: 'text',
                        name: 'surname',
                        placeholder: 'Soyisminiz',
                        value: this.userProfile.surname
                    }
                ],
                buttons: [
                    { text: 'Cancel' },
                    {
                        text: 'Save',
                        handler: data => {
                            this.profileService.updateName(data.surname);
                        }
                    }
                ]
            });
            return yield alert.present();
        });
    }
    updateEmail() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                inputs: [
                    { type: 'text', name: 'newEmail', placeholder: 'Your new email' },
                    { name: 'password', placeholder: 'Your password', type: 'password' }
                ],
                cssClass: 'custom-alert',
                buttons: [
                    { text: 'Cancel' },
                    {
                        text: 'Save',
                        handler: data => {
                            this.profileService
                                .updateEmail(data.newEmail, data.password)
                                .then(() => {
                                console.log('Email Changed Successfully');
                            })
                                .catch(error => {
                                console.log('ERROR: ' + error.message);
                            });
                        }
                    }
                ]
            });
            return yield alert.present();
        });
    }
    updatePassword() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                inputs: [
                    { name: 'newPassword', placeholder: 'New password', type: 'password' },
                    { name: 'oldPassword', placeholder: 'Old password', type: 'password' }
                ],
                cssClass: 'custom-alert',
                buttons: [
                    { text: 'Cancel' },
                    {
                        text: 'Save',
                        handler: data => {
                            this.profileService.updatePassword(data.newPassword, data.oldPassword);
                        }
                    }
                ]
            });
            return yield alert.present();
        });
    }
    homegit() {
        this.navctrl.navigateRoot("home");
    }
    rutin() {
        this.navctrl.navigateRoot("tab2");
    }
    rutingit() {
        this.navctrl.navigateRoot('rutins');
    }
};
ProfilePage.ctorParameters = () => [
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router },
    { type: src_app_services_profile_service__WEBPACK_IMPORTED_MODULE_3__.ProfileService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController }
];
ProfilePage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-profile',
        template: _raw_loader_profile_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_profile_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], ProfilePage);



/***/ }),

/***/ 231:
/*!*******************************************!*\
  !*** ./src/app/profile/profile.page.scss ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".text-center {\n  text-align: center;\n}\n\n.text-left {\n  text-align: left;\n}\n\nion-content {\n  --background: whitesmoke;\n  /* fallback for old browsers */\n}\n\nion-item {\n  --background: transparent;\n}\n\n.cardavatar {\n  align-items: center;\n  text-align: center;\n  --background: transparent;\n  box-shadow: none;\n  border: none;\n}\n\nion-col {\n  text-align: center;\n}\n\n.tabbaralt {\n  border-radius: 20px 20px 0px 0px;\n}\n\n.name {\n  color: black;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2ZpbGUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0Usa0JBQUE7QUFBRjs7QUFHQTtFQUNFLGdCQUFBO0FBQUY7O0FBRUE7RUFFRSx3QkFBQTtFQUEyQiw4QkFBQTtBQUM3Qjs7QUFJQTtFQUNDLHlCQUFBO0FBREQ7O0FBSUE7RUFDRSxtQkFBQTtFQUNFLGtCQUFBO0VBQ0EseUJBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7QUFESjs7QUFHQTtFQUNFLGtCQUFBO0FBQUY7O0FBR0E7RUFDRSxnQ0FBQTtBQUFGOztBQUlBO0VBQ0UsWUFBQTtBQURGIiwiZmlsZSI6InByb2ZpbGUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbi50ZXh0LWNlbnRlciB7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG4udGV4dC1sZWZ0IHtcclxuICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG59XHJcbmlvbi1jb250ZW50IHtcclxuXHJcbiAgLS1iYWNrZ3JvdW5kOiB3aGl0ZXNtb2tlOyAgLyogZmFsbGJhY2sgZm9yIG9sZCBicm93c2VycyAqL1xyXG5cclxufVxyXG5cclxuXHJcbmlvbi1pdGVte1xyXG4gLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxufVxyXG5cclxuLmNhcmRhdmF0YXJ7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICBib3gtc2hhZG93OiBub25lO1xyXG4gICAgYm9yZGVyOiBub25lO1xyXG59XHJcbmlvbi1jb2x7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG4udGFiYmFyYWx0e1xyXG4gIGJvcmRlci1yYWRpdXM6IDIwcHggMjBweCAwcHggMHB4O1xyXG59XHJcblxyXG5cclxuLm5hbWV7XHJcbiAgY29sb3I6IGJsYWNrO1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ 2907:
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/profile/profile.page.html ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\r\n<ion-content [fullscreen]=\"true\" style=\"    --padding-bottom: 50px;\">\r\n\r\n\r\n  <ion-toolbar style=\"--background: transparent;\">\r\n    <ion-item style=\"--background: transparent;\" lines=\"none\">\r\n    <ion-title style=\"color: Black;\" size=\"large\" color=\"primary\">Profil</ion-title>\r\n          <ion-button disabled shape=\"round\" fill=\"clear\" style=\"--color:transparent;\" size=\"large\" slot=\"end\"><ion-icon name=\"add-circle\"></ion-icon></ion-button>\r\n\r\n  </ion-item>\r\n</ion-toolbar>\r\n\r\n\r\n  <ion-card style=\"     max-width: 900px;\r\n  box-shadow: none;\r\n  margin: 10px;\r\n  background: white;\r\n  border-radius: 20px;\r\n  border-style: solid;\r\n  border-color: transparent;\r\n  top: 1%;\">\r\n\r\n<ion-card class=\"cardavatar\">\r\n  <ion-icon style=\"    font-size: 10rem;\r\n  color: #0099ff;\r\n  border-style: solid;\r\n    border-radius: 100px;\r\n    border-color: black;\r\n  \" name=\"person\">\r\n\r\n  </ion-icon>\r\n   <h1 class=\"name\">  {{userProfile?.name}} {{userProfile?.surname}}</h1>\r\n</ion-card>\r\n\r\n\r\n  <ion-item lines=\"none\" >\r\n    <ion-label>\r\n      <ion-grid>\r\n        <ion-row>\r\n          <ion-col class=\"text-left\" size=\"5\"> İsim </ion-col>\r\n          <ion-col class=\"text-center\" size=\"7\" *ngIf=\"userProfile?.name\">\r\n            {{userProfile?.name}}\r\n          </ion-col>\r\n          <ion-col size=\"7\" class=\"placeholder-profile text-center\" *ngIf=\"!userProfile?.name\">\r\n            <span>Düzenle </span>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ion-label>\r\n  </ion-item>\r\n\r\n  <ion-item lines=\"none\" >\r\n    <ion-label>\r\n      <ion-grid>\r\n        <ion-row>\r\n          <ion-col class=\"text-left\" size=\"5\"> Soyisim </ion-col>\r\n          <ion-col class=\"text-center\" size=\"7\" *ngIf=\"userProfile?.surname\">\r\n            {{userProfile?.surname}}\r\n          </ion-col>\r\n          <ion-col size=\"7\" class=\"placeholder-profile text-center\" *ngIf=\"!userProfile?.surname\">\r\n            <span>Düzenle </span>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ion-label>\r\n  </ion-item>\r\n\r\n  <ion-item lines=\"none\"  >\r\n    <ion-label>\r\n      <ion-grid>\r\n        <ion-row>\r\n          <ion-col class=\"text-left\" size=\"5\"> Email </ion-col>\r\n          <ion-col class=\"text-center\" size=\"7\" *ngIf=\"userProfile?.email\">\r\n            {{userProfile?.email}}\r\n          </ion-col>\r\n          <ion-col size=\"7\" class=\"placeholder-profile text-center\" *ngIf=\"!userProfile?.email\">\r\n            <span>Düzenle </span>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ion-label>\r\n  </ion-item>\r\n\r\n\r\n<ion-item  lines=\"none\"  style=\"margin: 4%;\">\r\n  <ion-label slot=\"start\">\r\n    <ion-icon name=\"business-outline\"></ion-icon>\r\n    Destek</ion-label>\r\n    <ion-button slot=\"end\" fill=\"clear\" color=\"dark\" size=\"large\">></ion-button>\r\n  </ion-item>\r\n\r\n<ion-item  lines=\"none\"  style=\"margin: 4%;\">\r\n  <ion-label slot=\"start\">\r\n    <ion-icon name=\"chatbox-ellipses-outline\"></ion-icon>\r\n        Mesaj Merkezi</ion-label>\r\n  <ion-button slot=\"end\" fill=\"clear\" color=\"dark\" size=\"large\">></ion-button>\r\n</ion-item>\r\n\r\n<ion-item  lines=\"none\"  style=\"margin: 4%;\">\r\n  <ion-label style=\"font-size: small;\" slot=\"start\">\r\n    <ion-icon name=\"help-circle-outline\"></ion-icon>\r\n            SSS & Geribildirim</ion-label>\r\n  <ion-button slot=\"end\" fill=\"clear\" color=\"dark\" size=\"large\">></ion-button>\r\n</ion-item>\r\n\r\n\r\n<ion-item lines=\"none\" style=\"margin: 4%;\">\r\n\r\n            <ion-button slot=\"end\" fill=\"clear\" (click)=\"logOut()\" color=\"danger\">\r\n              <ion-label style=\"margin-top: 7px;\">Çıkış Yap</ion-label>\r\n            </ion-button>\r\n          </ion-item>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n</ion-card>\r\n\r\n\r\n\r\n</ion-content>\r\n\r\n<ion-tab-bar\r\nslot=\"bottom\" >\r\n  <ion-tab-button (click)=\"homegit()\"  >\r\n    <ion-icon size=\"large\" name=\"home\"></ion-icon>\r\n  </ion-tab-button>\r\n\r\n\r\n  <ion-tab-button  selected=true >\r\n    <ion-icon size=\"large\"  name=\"person\"></ion-icon>\r\n  </ion-tab-button>\r\n</ion-tab-bar>\r\n");

/***/ })

}]);
//# sourceMappingURL=src_app_profile_profile_module_ts.js.map