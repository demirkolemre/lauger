(self["webpackChunkselsmart"] = self["webpackChunkselsmart"] || []).push([["src_app_rutins_rutins_module_ts"],{

/***/ 1816:
/*!*************************************************!*\
  !*** ./src/app/rutins/rutins-routing.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RutinsPageRoutingModule": () => (/* binding */ RutinsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _rutins_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./rutins.page */ 7703);




const routes = [
    {
        path: '',
        component: _rutins_page__WEBPACK_IMPORTED_MODULE_0__.RutinsPage
    }
];
let RutinsPageRoutingModule = class RutinsPageRoutingModule {
};
RutinsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], RutinsPageRoutingModule);



/***/ }),

/***/ 322:
/*!*****************************************!*\
  !*** ./src/app/rutins/rutins.module.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RutinsPageModule": () => (/* binding */ RutinsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 9122);
/* harmony import */ var _rutins_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./rutins-routing.module */ 1816);
/* harmony import */ var _rutins_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./rutins.page */ 7703);







let RutinsPageModule = class RutinsPageModule {
};
RutinsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _rutins_routing_module__WEBPACK_IMPORTED_MODULE_0__.RutinsPageRoutingModule
        ],
        declarations: [_rutins_page__WEBPACK_IMPORTED_MODULE_1__.RutinsPage]
    })
], RutinsPageModule);



/***/ }),

/***/ 7703:
/*!***************************************!*\
  !*** ./src/app/rutins/rutins.page.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RutinsPage": () => (/* binding */ RutinsPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _raw_loader_rutins_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./rutins.page.html */ 5921);
/* harmony import */ var _rutins_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./rutins.page.scss */ 5039);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 9122);
/* harmony import */ var _components_devicedit_devicedit_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/devicedit/devicedit.component */ 4518);
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/fire/firestore */ 6717);
/* harmony import */ var _services_profile_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/profile.service */ 7715);








let RutinsPage = class RutinsPage {
    constructor(navctrl, modalController, database, profileService) {
        this.navctrl = navctrl;
        this.modalController = modalController;
        this.database = database;
        this.profileService = profileService;
        this.hotkeys = [];
    }
    editdev(detay) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            console.log(detay);
            const modal = yield this.modalController.create({
                component: _components_devicedit_devicedit_component__WEBPACK_IMPORTED_MODULE_2__.DeviceditComponent,
                handle: true,
                breakpoints: [0, 0.25, 0.5, 0.75],
                initialBreakpoint: 0.25,
                cssClass: "devmodal",
                componentProps: {
                    data: detay,
                    durum: 1,
                    profilid: this.userid
                },
            });
            modal.present();
            yield modal.onWillDismiss();
        });
    }
    homegit() {
        this.navctrl.navigateRoot("home");
    }
    tab2git() {
        this.navctrl.navigateRoot("tab2");
    }
    profilgit() {
        this.navctrl.navigateRoot('profile');
    }
    segmentchange(e) {
        console.log(e.detail.value);
        if (e.detail.value == "ekle") {
            this.segmentvalue = true;
        }
        else if (e.detail.value == "gor") {
            this.segmentvalue = false;
        }
    }
    ionViewWillEnter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            this.profileService.getUserProfile().then(r => {
                this.userid = this.profileService.useridsi;
                this.database.collection("/kullanicilar/")
                    .doc(this.profileService.useridsi)
                    .collection("hotkeys")
                    .snapshotChanges().subscribe(actions => {
                    this.hotkeys = [];
                    actions.map(a => {
                        const data = a.payload.doc.data();
                        data.id = a.payload.doc.id;
                        console.log(data);
                        this.hotkeys.push(data);
                    });
                });
            });
        });
    }
    deldev(dev) {
        console.log(dev);
        this.database.collection("/kullanicilar/").doc(this.userid).collection("/hotkeys/").doc(dev.id).delete();
    }
};
RutinsPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ModalController },
    { type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_6__.AngularFirestore },
    { type: _services_profile_service__WEBPACK_IMPORTED_MODULE_3__.ProfileService }
];
RutinsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-rutins',
        template: _raw_loader_rutins_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_rutins_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], RutinsPage);



/***/ }),

/***/ 5039:
/*!*****************************************!*\
  !*** ./src/app/rutins/rutins.page.scss ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-content {\n  --background: linear-gradient(to bottom, #f2fcfe, rgba(240, 128, 128, 0.693)) !important;\n  /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */\n  --offset-bottom:8% !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJ1dGlucy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSx3RkFBQTtFQUNBLHFFQUFBO0VBQ0EsNkJBQUE7QUFDRiIsImZpbGUiOiJydXRpbnMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byBib3R0b20sICNmMmZjZmUsIHJnYmEoMjQwLCAxMjgsIDEyOCwgMC42OTMpKSAhaW1wb3J0YW50O1xuICAvKiBXM0MsIElFIDEwKy8gRWRnZSwgRmlyZWZveCAxNissIENocm9tZSAyNissIE9wZXJhIDEyKywgU2FmYXJpIDcrICovXG4gIC0tb2Zmc2V0LWJvdHRvbTo4JSAhaW1wb3J0YW50O1xufVxuIl19 */");

/***/ }),

/***/ 5921:
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/rutins/rutins.page.html ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n<ion-content>\n  <ion-toolbar style=\"--background: transparent; color: lightcoral;margin: 3%;\">\n    <ion-title>Rutinler</ion-title>\n  </ion-toolbar>\n\n\n\n\n <ion-grid>\n  <ion-row >\n\n    <ion-item-sliding  *ngFor=\"let dev of hotkeys\">\n\n      <ion-item-options side=\"start\"  style=\"    max-height: 90%;\n      margin-top: 2%;\">\n        <ion-item-option style=\"    border-radius: 20px;\n        width: 74px;\n        margin-right: 0.7%;\" color=\"warning\" (click)=\"editdev(dev)\">Düzenle</ion-item-option>\n      </ion-item-options>\n\n      <ion-item lines=\"none\" style=\"min-height: 130px;\n      background: white;\n      border-radius: 24px;\n      margin: 5px;\n      display: flex;\n      font-size: xx-large;\n  \">\n        <ion-label>{{dev.name}}</ion-label>\n        <ion-icon color=\"danger\" style=\"font-size: xx-large;\" name=\"bulb\"></ion-icon>\n      </ion-item>\n\n      <ion-item-options side=\"end\"  style=\"    max-height: 90%;\n      margin-top: 2%;\">\n\n        <ion-item-option style=\"border-radius: 20px;\" color=\"danger\" (click)=\"deldev(dev)\">Sil</ion-item-option>\n      </ion-item-options>\n    </ion-item-sliding>\n\n\n  </ion-row>\n </ion-grid>\n</ion-content>\n<ion-tab-bar  slot=\"bottom\">\n  <ion-tab-button (click)=\"homegit()\"  >\n    <ion-icon size=\"large\" name=\"home\"></ion-icon>\n  </ion-tab-button>\n\n  <ion-tab-button (click)=\"tab2git()\" >\n    <ion-icon size=\"large\"  name=\"git-network\"></ion-icon>\n  </ion-tab-button>\n\n  <ion-tab-button selected=\"true\" >\n    <ion-icon size=\"large\"  name=\"flash\"></ion-icon>\n  </ion-tab-button>\n\n  <ion-tab-button (click)=\"profilgit()\">\n    <ion-icon size=\"large\"  name=\"settings\"></ion-icon>\n  </ion-tab-button>\n</ion-tab-bar>\n\n");

/***/ })

}]);
//# sourceMappingURL=src_app_rutins_rutins_module_ts.js.map