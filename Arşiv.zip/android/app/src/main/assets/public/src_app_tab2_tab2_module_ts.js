(self["webpackChunkselsmart"] = self["webpackChunkselsmart"] || []).push([["src_app_tab2_tab2_module_ts"],{

/***/ 3092:
/*!*********************************************!*\
  !*** ./src/app/tab2/tab2-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab2PageRoutingModule": () => (/* binding */ Tab2PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _tab2_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab2.page */ 442);




const routes = [
    {
        path: '',
        component: _tab2_page__WEBPACK_IMPORTED_MODULE_0__.Tab2Page,
    }
];
let Tab2PageRoutingModule = class Tab2PageRoutingModule {
};
Tab2PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], Tab2PageRoutingModule);



/***/ }),

/***/ 7008:
/*!*************************************!*\
  !*** ./src/app/tab2/tab2.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab2PageModule": () => (/* binding */ Tab2PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 9122);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _tab2_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab2.page */ 442);
/* harmony import */ var _tab2_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tab2-routing.module */ 3092);







let Tab2PageModule = class Tab2PageModule {
};
Tab2PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _tab2_routing_module__WEBPACK_IMPORTED_MODULE_1__.Tab2PageRoutingModule
        ],
        declarations: [_tab2_page__WEBPACK_IMPORTED_MODULE_0__.Tab2Page]
    })
], Tab2PageModule);



/***/ }),

/***/ 442:
/*!***********************************!*\
  !*** ./src/app/tab2/tab2.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab2Page": () => (/* binding */ Tab2Page)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _raw_loader_tab2_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./tab2.page.html */ 2477);
/* harmony import */ var _tab2_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tab2.page.scss */ 2055);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 9122);
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/fire/firestore */ 6717);
/* harmony import */ var _services_profile_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/profile.service */ 7715);
/* harmony import */ var _angular_fire_database__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/fire/database */ 4134);









let Tab2Page = class Tab2Page {
    constructor(firestore, realdb, navctrl, profilservice, modalCtrl, toastController) {
        this.firestore = firestore;
        this.realdb = realdb;
        this.navctrl = navctrl;
        this.profilservice = profilservice;
        this.modalCtrl = modalCtrl;
        this.toastController = toastController;
        this.aradiklarim = [];
        this.cihazlar = [];
        this.cokaradiklarim = [];
        this.eklenen = [];
        this.segmentvalue = false;
        this.disablekayit = "disab";
        this.disablezaman = "disab";
        this.minDate = new Date().toISOString();
        this.weekdays = ["Paz", "Sal", "Çar", "Per", "Cum", "Cts", "Paz"];
    }
    kayitbut() {
        this.tomesaj("İşlem Ekleniyor");
        console.log(this.eklenen);
        var id = this.firestore.createId();
        this.firestore.collection("/kullanicilar/").doc(this.profilservice.useridsi).collection("hotkeys").doc(id).set({
            name: this.eklemeisim,
            devices: this.eklenen,
            profilid: this.profilservice.useridsi
        })
            .finally(() => {
            window.location.reload();
        });
    }
    cihazadi(e) {
        console.log(e.detail.value.length);
        if (e.detail.value.length > 2) {
            this.eklemeisim = e.detail.value;
            this.disablekayit = null;
        }
    }
    saatadi(a) {
        if (a.detail.value.length > 2) {
            this.zamanisim = a.detail.value;
            this.disablezaman = null;
        }
    }
    ionViewWillEnter() {
        console.log();
        this.profilservice.getUserProfile();
        this.realdb.database.ref("/dev/").get().then(r => {
            this.cihazlar = r.val();
            for (let key in this.cihazlar) {
                if (this.cihazlar[key].node != undefined) {
                    this.cokaradiklarim.push({
                        key: key,
                        data: this.cihazlar[key].node,
                        datalenght: 0,
                    });
                }
                else {
                    if (this.cihazlar[key].int == 1) {
                        this.aradiklarim.push({
                            data: this.cihazlar[key],
                            key: key,
                            value: true,
                        });
                    }
                    else {
                        this.aradiklarim.push({
                            data: this.cihazlar[key],
                            key: key,
                            value: false,
                        });
                    }
                }
            }
        });
    }
    segmentchange(e) {
        console.log(e.detail.value);
        if (e.detail.value == "tarih") {
            this.segmentvalue = true;
        }
        else if (e.detail.value == "coklu") {
            this.segmentvalue = false;
        }
    }
    bak(e, event) {
        console.log(event.detail.checked);
        console.log(e);
        if (event.detail.checked == true) {
            this.eklenen.push(e);
        }
        else {
            this.eklenen.splice(e.key, 1);
        }
        console.log(this.eklenen);
    }
    homegit() {
        this.navctrl.navigateRoot("home");
    }
    ayargit() {
        this.navctrl.navigateRoot("profile");
    }
    rutingit() {
        this.navctrl.navigateRoot("rutins");
    }
    kayitzaman() {
        console.log(this.zaman);
        this.realdb.database.ref("/autonom/" + this.zaman + "/" + this.realdb.createPushId()).set({
            zaman: this.zaman,
            who: this.profilservice.useridsi,
            data: "dataaaa"
        });
    }
    degisimzaman(zaman) {
        console.log(zaman.detail.value);
        this.zaman = zaman.detail.value.split(":")[0] + ":" + zaman.detail.value.split(":")[1];
        console.log(this.zaman);
    }
    tomesaj(mesaj) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: mesaj,
                duration: 3000,
                cssClass: 'custom-toast',
            });
            yield toast.present();
        });
    }
};
Tab2Page.ctorParameters = () => [
    { type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_4__.AngularFirestore },
    { type: _angular_fire_database__WEBPACK_IMPORTED_MODULE_5__.AngularFireDatabase },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController },
    { type: _services_profile_service__WEBPACK_IMPORTED_MODULE_2__.ProfileService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ToastController }
];
Tab2Page = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-tab2',
        template: _raw_loader_tab2_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_tab2_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], Tab2Page);



/***/ }),

/***/ 2055:
/*!*************************************!*\
  !*** ./src/app/tab2/tab2.page.scss ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".toolbar {\n  --background: transparent;\n}\n\nion-list {\n  background: transparent;\n}\n\nion-content {\n  --background: #1c92d2;\n  /* fallback for old browsers */\n  --background: -webkit-linear-gradient(to bottom, #f2fcfe, #1cd243);\n  /* Chrome 10-25, Safari 5.1-6 */\n  --background: linear-gradient(to bottom, #f2fcfe, #1cd243);\n  /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */\n}\n\n.box2 {\n  background: #7aff99;\n  box-shadow: inset -5px -5px 9px rgba(255, 255, 255, 0.45), inset 5px 5px 9px rgba(94, 104, 121, 0.3);\n}\n\ndiv {\n  height: 50%;\n  width: 30%;\n  background: #dde7de;\n  border-radius: 20px;\n  margin: 3px;\n}\n\n.box3 {\n  background: lightcoral;\n  box-shadow: -5px -5px 9px rgba(255, 255, 255, 0.45), inset 5px 5px 9px rgba(71, 26, 26, 0.49);\n}\n\n.box3 ion-icon {\n  font-size: 2rem;\n  color: gray;\n}\n\n.box3 ion-label {\n  color: whitesmoke;\n}\n\nion-item {\n  width: 100%;\n  --background: transparent;\n}\n\nion-checkbox:active {\n  animation: heartbeat 1.5s ease-in-out infinite both;\n}\n\n@keyframes heartbeat {\n  from {\n    transform: scale(1);\n    transform-origin: center center;\n    animation-timing-function: ease-out;\n  }\n  10% {\n    transform: scale(0.91);\n    animation-timing-function: ease-in;\n  }\n  17% {\n    transform: scale(0.98);\n    animation-timing-function: ease-out;\n  }\n  33% {\n    transform: scale(0.87);\n    animation-timing-function: ease-in;\n  }\n  45% {\n    transform: scale(1);\n    animation-timing-function: ease-out;\n  }\n}\n\n.segmentdiv {\n  background: transparent;\n  color: transparent;\n  width: 100%;\n}\n\n.daysdiv {\n  border-style: solid;\n  border-color: #1cd22e76;\n  width: 90%;\n  height: 150%;\n  background: white;\n  display: grid;\n  align-items: center;\n  justify-content: center;\n}\n\n.dayrow {\n  margin-bottom: 5%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRhYjIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UseUJBQUE7QUFDRjs7QUFFQTtFQUNFLHVCQUFBO0FBQ0Y7O0FBR0E7RUFDRSxxQkFBQTtFQUF3Qiw4QkFBQTtFQUN4QixrRUFBQTtFQUFxRSwrQkFBQTtFQUNyRSwwREFBQTtFQUE0RCxxRUFBQTtBQUc5RDs7QUFDQTtFQUNFLG1CQUFBO0VBQ0Esb0dBQUE7QUFFRjs7QUFDQTtFQUNFLFdBQUE7RUFDQSxVQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLFdBQUE7QUFFRjs7QUFDQTtFQUNFLHNCQUFBO0VBQ0EsNkZBQUE7QUFFRjs7QUFBRTtFQUNFLGVBQUE7RUFDQSxXQUFBO0FBRUo7O0FBQ0U7RUFDRSxpQkFBQTtBQUNKOztBQUdBO0VBQ0UsV0FBQTtFQUNBLHlCQUFBO0FBQUY7O0FBR0E7RUFFRSxtREFBQTtBQUFGOztBQXlDRTtFQUNFO0lBRUUsbUJBQUE7SUFFQSwrQkFBQTtJQUVBLG1DQUFBO0VBTEo7RUFRRTtJQUVFLHNCQUFBO0lBRUEsa0NBQUE7RUFOSjtFQVNFO0lBRUUsc0JBQUE7SUFFQSxtQ0FBQTtFQVBKO0VBVUU7SUFFRSxzQkFBQTtJQUVBLGtDQUFBO0VBUko7RUFXRTtJQUVFLG1CQUFBO0lBRUEsbUNBQUE7RUFUSjtBQUNGOztBQWNBO0VBQ0UsdUJBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7QUFYRjs7QUFjQTtFQUNFLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7QUFYRjs7QUFhQTtFQUNFLGlCQUFBO0FBVkYiLCJmaWxlIjoidGFiMi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudG9vbGJhciB7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG59XG5cbmlvbi1saXN0IHtcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG59XG5cblxuaW9uLWNvbnRlbnR7XG4gIC0tYmFja2dyb3VuZDogIzFjOTJkMjsgIC8qIGZhbGxiYWNrIGZvciBvbGQgYnJvd3NlcnMgKi9cbiAgLS1iYWNrZ3JvdW5kOiAtd2Via2l0LWxpbmVhci1ncmFkaWVudCh0byBib3R0b20sICNmMmZjZmUsICMxY2QyNDMpOyAgLyogQ2hyb21lIDEwLTI1LCBTYWZhcmkgNS4xLTYgKi9cbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gYm90dG9tLCAjZjJmY2ZlLCAjMWNkMjQzKTsgLyogVzNDLCBJRSAxMCsvIEVkZ2UsIEZpcmVmb3ggMTYrLCBDaHJvbWUgMjYrLCBPcGVyYSAxMissIFNhZmFyaSA3KyAqL1xuXG59XG5cbi5ib3gyIHtcbiAgYmFja2dyb3VuZDogIzdhZmY5OTtcbiAgYm94LXNoYWRvdzogaW5zZXQgLTVweCAtNXB4IDlweCByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuNDUpLCBpbnNldCA1cHggNXB4IDlweCByZ2JhKDk0LCAxMDQsIDEyMSwgMC4zKTtcbn1cblxuZGl2IHtcbiAgaGVpZ2h0OiA1MCU7XG4gIHdpZHRoOiAzMCU7XG4gIGJhY2tncm91bmQ6ICNkZGU3ZGU7XG4gIGJvcmRlci1yYWRpdXM6IDIwcHg7XG4gIG1hcmdpbjogM3B4O1xufVxuXG4uYm94MyB7XG4gIGJhY2tncm91bmQ6IGxpZ2h0Y29yYWw7XG4gIGJveC1zaGFkb3c6IC01cHggLTVweCA5cHggcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjQ1KSwgaW5zZXQgNXB4IDVweCA5cHggcmdiKDcxIDI2IDI2IC8gNDklKTtcblxuICBpb24taWNvbiB7XG4gICAgZm9udC1zaXplOiAycmVtO1xuICAgIGNvbG9yOiBncmF5O1xuICB9XG5cbiAgaW9uLWxhYmVsIHtcbiAgICBjb2xvcjogd2hpdGVzbW9rZTtcbiAgfVxufVxuXG5pb24taXRlbSB7XG4gIHdpZHRoOiAxMDAlO1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xufVxuXG5pb24tY2hlY2tib3g6YWN0aXZlIHtcbiAgLXdlYmtpdC1hbmltYXRpb246IGhlYXJ0YmVhdCAxLjVzIGVhc2UtaW4tb3V0IGluZmluaXRlIGJvdGg7XG4gIGFuaW1hdGlvbjogaGVhcnRiZWF0IDEuNXMgZWFzZS1pbi1vdXQgaW5maW5pdGUgYm90aDtcblxuICBALXdlYmtpdC1rZXlmcmFtZXMgaGVhcnRiZWF0IHtcbiAgICBmcm9tIHtcbiAgICAgIC13ZWJraXQtdHJhbnNmb3JtOiBzY2FsZSgxKTtcbiAgICAgIHRyYW5zZm9ybTogc2NhbGUoMSk7XG4gICAgICAtd2Via2l0LXRyYW5zZm9ybS1vcmlnaW46IGNlbnRlciBjZW50ZXI7XG4gICAgICB0cmFuc2Zvcm0tb3JpZ2luOiBjZW50ZXIgY2VudGVyO1xuICAgICAgLXdlYmtpdC1hbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLW91dDtcbiAgICAgIGFuaW1hdGlvbi10aW1pbmctZnVuY3Rpb246IGVhc2Utb3V0XG4gICAgfVxuXG4gICAgMTAlIHtcbiAgICAgIC13ZWJraXQtdHJhbnNmb3JtOiBzY2FsZSguOTEpO1xuICAgICAgdHJhbnNmb3JtOiBzY2FsZSguOTEpO1xuICAgICAgLXdlYmtpdC1hbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluO1xuICAgICAgYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogZWFzZS1pblxuICAgIH1cblxuICAgIDE3JSB7XG4gICAgICAtd2Via2l0LXRyYW5zZm9ybTogc2NhbGUoLjk4KTtcbiAgICAgIHRyYW5zZm9ybTogc2NhbGUoLjk4KTtcbiAgICAgIC13ZWJraXQtYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogZWFzZS1vdXQ7XG4gICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLW91dFxuICAgIH1cblxuICAgIDMzJSB7XG4gICAgICAtd2Via2l0LXRyYW5zZm9ybTogc2NhbGUoLjg3KTtcbiAgICAgIHRyYW5zZm9ybTogc2NhbGUoLjg3KTtcbiAgICAgIC13ZWJraXQtYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogZWFzZS1pbjtcbiAgICAgIGFuaW1hdGlvbi10aW1pbmctZnVuY3Rpb246IGVhc2UtaW5cbiAgICB9XG5cbiAgICA0NSUge1xuICAgICAgLXdlYmtpdC10cmFuc2Zvcm06IHNjYWxlKDEpO1xuICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTtcbiAgICAgIC13ZWJraXQtYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogZWFzZS1vdXQ7XG4gICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLW91dFxuICAgIH1cbiAgfVxuXG4gIEBrZXlmcmFtZXMgaGVhcnRiZWF0IHtcbiAgICBmcm9tIHtcbiAgICAgIC13ZWJraXQtdHJhbnNmb3JtOiBzY2FsZSgxKTtcbiAgICAgIHRyYW5zZm9ybTogc2NhbGUoMSk7XG4gICAgICAtd2Via2l0LXRyYW5zZm9ybS1vcmlnaW46IGNlbnRlciBjZW50ZXI7XG4gICAgICB0cmFuc2Zvcm0tb3JpZ2luOiBjZW50ZXIgY2VudGVyO1xuICAgICAgLXdlYmtpdC1hbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLW91dDtcbiAgICAgIGFuaW1hdGlvbi10aW1pbmctZnVuY3Rpb246IGVhc2Utb3V0XG4gICAgfVxuXG4gICAgMTAlIHtcbiAgICAgIC13ZWJraXQtdHJhbnNmb3JtOiBzY2FsZSguOTEpO1xuICAgICAgdHJhbnNmb3JtOiBzY2FsZSguOTEpO1xuICAgICAgLXdlYmtpdC1hbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluO1xuICAgICAgYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogZWFzZS1pblxuICAgIH1cblxuICAgIDE3JSB7XG4gICAgICAtd2Via2l0LXRyYW5zZm9ybTogc2NhbGUoLjk4KTtcbiAgICAgIHRyYW5zZm9ybTogc2NhbGUoLjk4KTtcbiAgICAgIC13ZWJraXQtYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogZWFzZS1vdXQ7XG4gICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLW91dFxuICAgIH1cblxuICAgIDMzJSB7XG4gICAgICAtd2Via2l0LXRyYW5zZm9ybTogc2NhbGUoLjg3KTtcbiAgICAgIHRyYW5zZm9ybTogc2NhbGUoLjg3KTtcbiAgICAgIC13ZWJraXQtYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogZWFzZS1pbjtcbiAgICAgIGFuaW1hdGlvbi10aW1pbmctZnVuY3Rpb246IGVhc2UtaW5cbiAgICB9XG5cbiAgICA0NSUge1xuICAgICAgLXdlYmtpdC10cmFuc2Zvcm06IHNjYWxlKDEpO1xuICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTtcbiAgICAgIC13ZWJraXQtYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogZWFzZS1vdXQ7XG4gICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLW91dFxuICAgIH1cbiAgfVxufVxuXG5cbi5zZWdtZW50ZGl2IHtcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gIGNvbG9yOiB0cmFuc3BhcmVudDtcbiAgd2lkdGg6IDEwMCU7XG59XG5cbi5kYXlzZGl2e1xuICBib3JkZXItc3R5bGU6IHNvbGlkO1xuICBib3JkZXItY29sb3I6ICMxY2QyMmU3NjtcbiAgd2lkdGg6IDkwJTtcbiAgaGVpZ2h0OiAxNTAlO1xuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgZGlzcGxheTogZ3JpZDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG59XG4uZGF5cm93e1xuICBtYXJnaW4tYm90dG9tOiA1JTtcbn1cbiJdfQ== */");

/***/ }),

/***/ 2477:
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tab2/tab2.page.html ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n\n\n\n<ion-toolbar style=\"--background: transparent; color: green;margin: 3%;\">\n  <ion-title style=\"font-size: x-large;\">Rutinler & Otomasyonlar</ion-title>\n</ion-toolbar>\n\n<ion-content [fullscreen]=\"true\">\n\n  <ion-segment style=\"max-width: 90%; margin: auto;\" color=\"danger\" mode=\"ios\" value=\"coklu\" (ionChange)=\"segmentchange($event)\">\n    <ion-segment-button value=\"tarih\">Tarih</ion-segment-button>\n    <ion-segment-button value=\"coklu\">Çoklu Seçim</ion-segment-button>\n\n  </ion-segment>\n\n  <div class=\"segmentdiv\"  *ngIf=\"!segmentvalue\">\n\n    <ion-card style=\"    border-radius: 8px;\nbackground: aliceblue;\nbox-shadow: -1px 4px 5px 5px #b5d2e96e;\npadding-bottom: 5px;\n\">\n\n<ion-item lines=\"none\" style=\"--background: transparent;\">\n  <h1 style=\"    margin-left: 5%;\n  color: #00ff26;\">Cihaz Seç\n  </h1>\n</ion-item>\n\n\n  <ion-row style=\"justify-content: center;\">\n    <div id=\"b\"  *ngFor=\"let cihaz of aradiklarim\" class=\"box2\">\n    <ion-item lines=\"none\" style=\"--background: transparent; margin-bottom: -45%;\">\n  </ion-item>\n      <ion-grid >\n        <ion-row>\n          <ion-label\n          style=\"font-family: sans-serif; font-size: x-large; padding: 10px; color: white;\"\n          >{{ cihaz.data.name }}</ion-label\n        >\n        </ion-row>\n        <ion-row>\n          <ion-col>\n            <ion-label\n              style=\" color: lightcyan; font-family: sans-serif; font-size: xx-small;\"\n              >{{ cihaz.key }}</ion-label\n            >\n          </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col >\n            <!--\n            <ion-toggle\n              [enableOnOffLabels]=\"true\"\n              mode=\"ios\"\n              [(ngModel)]=\"cihaz.value\" (ionChange)=\"bak(cihaz)\"\n            ></ion-toggle>-->\n            <ion-checkbox mode=\"ios\" (ionChange)=\"bak(cihaz,$event)\" mode=\"ios\">\n\n            </ion-checkbox>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </div>\n  </ion-row>\n  <ion-row *ngIf=\"eklenen.length == 1\" style=\"text-align: center; justify-content: center;\">En az 2 seçim yapılmalı</ion-row>\n  <ion-row  *ngIf=\"eklenen?.length > 1\">\n    <ion-title>\n      Seçilenler\n    </ion-title>\n    <ion-item>\n      <ion-label>Cihaz Adı</ion-label>\n      <ion-input (ionChange)=\"cihazadi($event)\" placeholder=\"Cihaz Adı girin\"></ion-input>\n    </ion-item>\n\n    <ion-list style=\"width: 100%;\">\n      <ion-item  *ngFor=\"let item of eklenen\">\n        <ion-label>\n         {{item.data.name }}\n        </ion-label>\n      </ion-item>\n    </ion-list>\n\n    <ion-button style=\"    width: 100%;\n    margin: 0px 5px 0px 5px;\" [disabled]=\"disablekayit\" (click)=\"kayitbut()\"> Kayıt Et</ion-button>\n  </ion-row>\n\n\n\n\n  <ion-row class=\"dayrow\">\n    <ion-col>\n      <div class=\"daysdiv\">\n        <ion-row>\n          <ion-label style=\"margin: auto;\">Paz</ion-label>\n        </ion-row>\n        <ion-row>\n          <ion-checkbox style=\"margin: auto;\"></ion-checkbox>\n        </ion-row>\n      </div>\n    </ion-col>\n    <ion-col>\n      <div class=\"daysdiv\">\n        <ion-row>\n          <ion-label style=\"margin: auto;\">Sal</ion-label>\n        </ion-row>\n        <ion-row>\n          <ion-checkbox style=\"margin: auto;\"></ion-checkbox>\n        </ion-row>\n      </div>\n    </ion-col>\n    <ion-col>\n      <div class=\"daysdiv\">\n        <ion-row>\n          <ion-label style=\"margin: auto;\">Çar</ion-label>\n        </ion-row>\n        <ion-row>\n          <ion-checkbox style=\"margin: auto;\"></ion-checkbox>\n        </ion-row>\n      </div>\n    </ion-col>\n    <ion-col>\n      <div class=\"daysdiv\">\n        <ion-row>\n          <ion-label style=\"margin: auto;\">Per</ion-label>\n        </ion-row>\n        <ion-row>\n          <ion-checkbox style=\"margin: auto;\"></ion-checkbox>\n        </ion-row>\n      </div>\n    </ion-col>\n    <ion-col>\n      <div class=\"daysdiv\">\n        <ion-row>\n          <ion-label style=\"margin: auto;\">Cum</ion-label>\n        </ion-row>\n        <ion-row>\n          <ion-checkbox style=\"margin: auto;\"></ion-checkbox>\n        </ion-row>\n      </div>\n    </ion-col>\n    <ion-col>\n      <div class=\"daysdiv\">\n        <ion-row>\n          <ion-label style=\"margin: auto;\">Cmt</ion-label>\n        </ion-row>\n        <ion-row>\n          <ion-checkbox style=\"margin: auto;\"></ion-checkbox>\n        </ion-row>\n      </div>\n    </ion-col>\n    <ion-col>\n      <div class=\"daysdiv\">\n        <ion-row>\n          <ion-label style=\"margin: auto;\">Paz</ion-label>\n        </ion-row>\n        <ion-row>\n          <ion-checkbox style=\"margin: auto;\"></ion-checkbox>\n        </ion-row>\n      </div>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-item>\n      <ion-label>Saat</ion-label>\n      <ion-datetime-button datetime=\"datetime\"></ion-datetime-button>\n\n<ion-modal [keepContentsMounted]=\"true\">\n  <ng-template>\n    <ion-datetime style=\"color: black;\" presentation=\"time\" id=\"datetime\"></ion-datetime>\n  </ng-template>\n</ion-modal>\n    </ion-item>\n\n  </ion-row>\n</ion-card>\n  </div>\n\n\n  <div class=\"segmentdiv\"  *ngIf=\"segmentvalue\">\n\n\n      <ion-datetime\n      min=\"{{minDate}}\"\n      (ionChange)=\"degisimzaman($event)\"\n      style=\"    color: black;\n      margin: auto;\n      margin-top: 5%;\n      border-radius: 20px;\n      box-shadow: 1px 1px 19px 1px lightskyblue;\" locale=\"tr-TR\">\n      <span slot=\"time-label\">Saat</span>\n\n    </ion-datetime>\n\n\n\n\n    <ion-card style=\"margin: 6%; border-radius: 10px;\">\n\n      <ion-item>\n        <ion-label>Zamanlayıcı Adı</ion-label>\n        <ion-input (ionChange)=\"saatadi($event)\" placeholder=\"Zamanlayıcı Adı girin\"></ion-input>\n      </ion-item>\n\n      <ion-button [disabled]=\"disablezaman\" expand=\"block\" (click)=\"kayitzaman()\">Kaydet</ion-button>\n    </ion-card>\n  </div>\n</ion-content>\n\n\n  <ion-tab-bar  slot=\"bottom\">\n    <ion-tab-button (click)=\"homegit()\"  >\n      <ion-icon size=\"large\" name=\"home\"></ion-icon>\n    </ion-tab-button>\n\n    <ion-tab-button selected=true  >\n      <ion-icon size=\"large\"  name=\"git-network\"></ion-icon>\n    </ion-tab-button>\n\n    <ion-tab-button (click)=\"rutingit()\" >\n      <ion-icon size=\"large\"  name=\"flash\"></ion-icon>\n    </ion-tab-button>\n\n    <ion-tab-button (click)=\"ayargit()\">\n      <ion-icon size=\"large\"  name=\"settings\"></ion-icon>\n    </ion-tab-button>\n  </ion-tab-bar>\n\n");

/***/ })

}]);
//# sourceMappingURL=src_app_tab2_tab2_module_ts.js.map