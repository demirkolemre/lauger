(self["webpackChunkselsmart"] = self["webpackChunkselsmart"] || []).push([["src_app_demo_demo_module_ts"],{

/***/ 2199:
/*!*********************************************!*\
  !*** ./src/app/demo/demo-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DemoPageRoutingModule": () => (/* binding */ DemoPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _demo_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./demo.page */ 2311);




const routes = [
    {
        path: '',
        component: _demo_page__WEBPACK_IMPORTED_MODULE_0__.DemoPage
    }
];
let DemoPageRoutingModule = class DemoPageRoutingModule {
};
DemoPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], DemoPageRoutingModule);



/***/ }),

/***/ 849:
/*!*************************************!*\
  !*** ./src/app/demo/demo.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DemoPageModule": () => (/* binding */ DemoPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 9122);
/* harmony import */ var _demo_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./demo-routing.module */ 2199);
/* harmony import */ var _demo_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./demo.page */ 2311);







let DemoPageModule = class DemoPageModule {
};
DemoPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _demo_routing_module__WEBPACK_IMPORTED_MODULE_0__.DemoPageRoutingModule
        ],
        declarations: [_demo_page__WEBPACK_IMPORTED_MODULE_1__.DemoPage]
    })
], DemoPageModule);



/***/ }),

/***/ 2311:
/*!***********************************!*\
  !*** ./src/app/demo/demo.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DemoPage": () => (/* binding */ DemoPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _raw_loader_demo_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./demo.page.html */ 2453);
/* harmony import */ var _demo_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./demo.page.scss */ 6279);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);




let DemoPage = class DemoPage {
    constructor() { }
    ngOnInit() {
    }
    bak(event) {
        console.log(event.detail.checked);
        if (event.detail.checked == true) {
            document.getElementById("bulb").style.color = "lightcoral";
            document.getElementById("bb").style.boxShadow = "1px 0px 19px 5px lightcoral";
        }
        else {
            document.getElementById("bulb").style.color = "gray";
            document.getElementById("bb").style.boxShadow = "none";
        }
    }
};
DemoPage.ctorParameters = () => [];
DemoPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-demo',
        template: _raw_loader_demo_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_demo_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], DemoPage);



/***/ }),

/***/ 6279:
/*!*************************************!*\
  !*** ./src/app/demo/demo.page.scss ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-label {\n  font-family: sans-serif;\n  font-weight: bolder;\n}\n\nion-content {\n  --background: #dde1e7;\n}\n\n.box2 {\n  box-shadow: inset -5px -5px 9px rgba(255, 255, 255, 0.45), inset 5px 5px 9px rgba(94, 104, 121, 0.3);\n}\n\n.box3 {\n  background: lightcoral;\n  box-shadow: -5px -5px 9px rgba(255, 255, 255, 0.45), inset 5px 5px 9px #ac5252;\n}\n\n.box3 ion-icon {\n  font-size: 2rem;\n  color: gray;\n}\n\n.box3 ion-label {\n  color: whitesmoke;\n}\n\ndiv {\n  height: 65%;\n  width: 100%;\n  background: #dde1e7;\n  border-radius: 20px;\n  margin: 20px;\n}\n\nion-slides {\n  --bullet-background: gray;\n  --bullet-background-active: lightcoral;\n}\n\nion-toggle {\n  padding: 0px 9px 20px 10px;\n  --handle-width: 40px;\n  --handle-height: 30px;\n  --handle-max-height: auto;\n  --handle-spacing: 0px;\n  contain: none;\n}\n\nion-toggle::part(track),\nion-toggle.toggle-checked::part(track) {\n  width: 60px;\n  box-shadow: -5px -5px 9px rgba(255, 255, 255, 0.45), inset 5px 5px 9px #7b7b7ba3;\n  /* Required for iOS handle to overflow the height of the track */\n  overflow: visible;\n}\n\nion-toggle::part(handle) {\n  background: #ddd;\n  box-shadow: none;\n}\n\nion-toggle.toggle-checked::part(handle) {\n  background: lightcoral;\n  box-shadow: 3px -2px 0px rgba(255, 255, 255, 0.45), inset 5px 5px 9px #7b7b7ba3;\n}\n\nion-toggle.toggle-checked::part(track) {\n  background: lightcoral;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRlbW8ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVBO0VBQ0UsdUJBQUE7RUFDQSxtQkFBQTtBQURGOztBQUtBO0VBQ0UscUJBQUE7QUFGRjs7QUFRQTtFQUNBLG9HQUFBO0FBTEE7O0FBUUE7RUFDRSxzQkFBQTtFQUNBLDhFQUFBO0FBTEY7O0FBT0U7RUFDRSxlQUFBO0VBQ0EsV0FBQTtBQUxKOztBQU9FO0VBQ0UsaUJBQUE7QUFMSjs7QUFTQTtFQUNFLFdBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7QUFORjs7QUFXQTtFQUNFLHlCQUFBO0VBQ0Esc0NBQUE7QUFSRjs7QUFXQztFQUNDLDBCQUFBO0VBRUEsb0JBQUE7RUFDQSxxQkFBQTtFQUNBLHlCQUFBO0VBQ0EscUJBQUE7RUFFQSxhQUFBO0FBVkY7O0FBYUE7O0VBR0UsV0FBQTtFQUNBLGdGQUFBO0VBRUEsZ0VBQUE7RUFDQSxpQkFBQTtBQVpGOztBQWVBO0VBQ0UsZ0JBQUE7RUFHQSxnQkFBQTtBQWRGOztBQWlCQTtFQUNFLHNCQUFBO0VBQ0EsK0VBQUE7QUFkRjs7QUFpQkE7RUFDRSxzQkFBQTtBQWRGIiwiZmlsZSI6ImRlbW8ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXG5cbmlvbi1sYWJlbHtcbiAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XG4gIGZvbnQtd2VpZ2h0OiBib2xkZXI7XG59XG5cblxuaW9uLWNvbnRlbnR7XG4gIC0tYmFja2dyb3VuZDogI2RkZTFlNztcbn1cblxuXG5cblxuLmJveDJ7XG5ib3gtc2hhZG93OiBpbnNldCAtNXB4IC01cHggOXB4IHJnYmEoMjU1LDI1NSwyNTUsMC40NSksIGluc2V0IDVweCA1cHggOXB4IHJnYmEoOTQsMTA0LDEyMSwwLjMpO1xufVxuXG4uYm94M3tcbiAgYmFja2dyb3VuZDogbGlnaHRjb3JhbDtcbiAgYm94LXNoYWRvdzogIC01cHggLTVweCA5cHggcmdiYSgyNTUsMjU1LDI1NSwwLjQ1KSwgaW5zZXQgNXB4IDVweCA5cHggcmdiKDE3MiwgODIsIDgyKTtcblxuICBpb24taWNvbntcbiAgICBmb250LXNpemU6IDJyZW07XG4gICAgY29sb3I6IGdyYXk7XG4gIH1cbiAgaW9uLWxhYmVse1xuICAgIGNvbG9yOiB3aGl0ZXNtb2tlO1xuICB9XG4gIH1cblxuZGl2e1xuICBoZWlnaHQ6IDY1JTtcbiAgd2lkdGg6IDEwMCU7XG4gIGJhY2tncm91bmQ6ICNkZGUxZTc7XG4gIGJvcmRlci1yYWRpdXM6IDIwcHg7XG4gIG1hcmdpbjogMjBweDtcbiB9XG5cblxuXG5pb24tc2xpZGVze1xuICAtLWJ1bGxldC1iYWNrZ3JvdW5kXHQ6IGdyYXk7XG4gIC0tYnVsbGV0LWJhY2tncm91bmQtYWN0aXZlOiBsaWdodGNvcmFsO1xufVxuXG4gaW9uLXRvZ2dsZSB7XG4gIHBhZGRpbmc6IDBweCA5cHggMjBweCAxMHB4O1xuXG4gIC0taGFuZGxlLXdpZHRoOiA0MHB4O1xuICAtLWhhbmRsZS1oZWlnaHQ6IDMwcHg7XG4gIC0taGFuZGxlLW1heC1oZWlnaHQ6IGF1dG87XG4gIC0taGFuZGxlLXNwYWNpbmc6IDBweDtcblxuICBjb250YWluOiBub25lO1xufVxuXG5pb24tdG9nZ2xlOjpwYXJ0KHRyYWNrKSxcbmlvbi10b2dnbGUudG9nZ2xlLWNoZWNrZWQ6OnBhcnQodHJhY2spIHtcbiAgLy9oZWlnaHQ6IDEwcHg7XG4gIHdpZHRoOiA2MHB4O1xuICBib3gtc2hhZG93OiAtNXB4IC01cHggOXB4IHJnYmEoMjU1LCAyNTUsIDI1NSwgMC40NSksIGluc2V0IDVweCA1cHggOXB4ICM3YjdiN2JhMztcblxuICAvKiBSZXF1aXJlZCBmb3IgaU9TIGhhbmRsZSB0byBvdmVyZmxvdyB0aGUgaGVpZ2h0IG9mIHRoZSB0cmFjayAqL1xuICBvdmVyZmxvdzogdmlzaWJsZTtcbn1cblxuaW9uLXRvZ2dsZTo6cGFydChoYW5kbGUpIHtcbiAgYmFja2dyb3VuZDogI2RkZDtcblxuICAvL2JvcmRlci1yYWRpdXM6IDR4O1xuICBib3gtc2hhZG93OiBub25lO1xufVxuXG5pb24tdG9nZ2xlLnRvZ2dsZS1jaGVja2VkOjpwYXJ0KGhhbmRsZSkge1xuICBiYWNrZ3JvdW5kOiBsaWdodGNvcmFsO1xuICBib3gtc2hhZG93OjNweCAtMnB4IDBweCByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuNDUpLCBpbnNldCA1cHggNXB4IDlweCAjN2I3YjdiYTM7XG5cbn1cbmlvbi10b2dnbGUudG9nZ2xlLWNoZWNrZWQ6OnBhcnQodHJhY2spe1xuICBiYWNrZ3JvdW5kOiBsaWdodGNvcmFsO1xufVxuXG5cblxuXG5cblxuIl19 */");

/***/ }),

/***/ 2453:
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/demo/demo.page.html ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <h1 style=\"    z-index: 2222;\n  position: absolute;\n  font-family: sans-serif;\n  font-weight: revert;\n  margin: 20px;\n  color: lightcoral;\n  -webkit-text-stroke-width: 1px;\n  -webkit-text-stroke-color: #eb455a;\n  text-shadow: 1px 3px 7px white;\">SelSmart</h1>\n  <ion-fab vertical=\"top\" horizontal=\"end\" slot=\"fixed\">\n    <ion-fab-button color=\"danger\">\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n  <!--\n\n    <div class=\"box2\">\n    <ion-grid>\n      <ion-row>\n        <ion-icon\n          class=\"aa\"\n          style=\"\n            font-size: xx-large;\n            color: gray;\n            padding: 12px;\n            padding-bottom: 0px;\n          \"\n          name=\"bulb\"\n        ></ion-icon\n      ></ion-row>\n      <ion-row>\n        <ion-col>\n          <ion-label style=\"padding: 0px 0px 13px 13px; font-family: sans-serif\"\n            >Air Lamp</ion-label\n          >\n        </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col>\n          <ion-toggle\n            (ionChange)=\"bak($event)\"\n            [enableOnOffLabels]=\"true\"\n            mode=\"ios\"\n          ></ion-toggle>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </div>\n\n  <div class=\"box3\">\n    <ion-grid style=\"padding: 13px\">\n      <ion-row>\n        <ion-col><ion-icon name=\"options\"></ion-icon></ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col><ion-label>Kontrol</ion-label></ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col><ion-label>Merkezi</ion-label></ion-col>\n      </ion-row>\n    </ion-grid>\n  </div>\n-->\n\n\n\n  <ion-grid >\n    <ion-row>\n      <ion-col>\n\n        <ion-slides  pager=\"true\" style=\"padding-bottom: 7%; margin-bottom: -7%; margin-top: 5%;\">\n          <ion-slide    >\n            <img style=\"    max-width: 97%;\n            border-radius: 150px 150px 10px 10px;\n            height: 300px;\n            object-fit: inherit;\" src=\"../../assets/img/home.jpg\" alt=\"\">\n          </ion-slide>\n\n          <ion-slide   >\n            <img style=\"    max-width: 97%;\n            border-radius: 150px 150px 10px 10px;\n            height: 300px;\n            object-fit: inherit;\" src=\"../../assets/img/home.jpg\" alt=\"\">\n          </ion-slide>\n\n\n          <ion-slide   >\n            <img style=\"    max-width: 97%;\n            border-radius: 150px 150px 10px 10px;\n            height: 300px;\n            object-fit: inherit;\" src=\"../../assets/img/home.jpg\" alt=\"\">\n          </ion-slide>\n        </ion-slides>\n\n\n      </ion-col>\n    </ion-row>\n\n\n\n    <ion-row>\n      <ion-col>\n        <h1 style=\"font-family: sans-serif; font-size: xx-large; font-weight: bolder;\">Hoşgeldiniz</h1>\n        <p style=\" font-family: sans-serif; margin-top: -2%;\">Smart Systems</p>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n\n\n  <ion-grid style=\"    left: -6%; margin-top: -10%;\n  position: fixed;\n  right: 4%;\">\n    <ion-row style=\"margin-bottom: -16%;\">\n      <ion-col size=\"4 \">\n        <div class=\"box2\">\n          <ion-grid>\n            <ion-row>\n              <div id=\"bb\" style=\"border-radius: 20px;\n              width: 7%;\n              height: 30px;\n              margin: 6px 13px 7px 24px;\n              box-shadow: none;\n              \">\n              <ion-icon\n                class=\"aa\"\n                id=\"bulb\"\n                style=\"\n                  font-size: xx-large;\n                  color: gray;\n                  margin-left: -12px;\n                  margin-top: -1px;\n                \"\n                name=\"bulb\"\n              ></ion-icon\n            >\n                </div>\n\n          </ion-row>\n            <ion-row>\n              <ion-col>\n                <ion-label\n                  style=\"padding: 0px 0px 13px 13px; font-family: sans-serif\"\n                  >Air Lamp</ion-label\n                >\n              </ion-col>\n            </ion-row>\n            <ion-row>\n              <ion-col>\n                <ion-toggle\n                  (ionChange)=\"bak($event)\"\n                  [enableOnOffLabels]=\"true\"\n                  mode=\"ios\"\n                ></ion-toggle>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n        </div>\n      </ion-col>\n\n      <ion-col size=\"4\">\n        <div class=\"box2\">\n          <ion-grid>\n            <ion-row>\n              <ion-icon\n                class=\"aa\"\n                style=\"\n                  font-size: xx-large;\n                  color: gray;\n                  padding: 12px;\n                  padding-bottom: 0px;\n                \"\n                name=\"bulb\"\n              ></ion-icon\n            ></ion-row>\n            <ion-row>\n              <ion-col>\n                <ion-label\n                  style=\"padding: 0px 0px 13px 13px; font-family: sans-serif\"\n                  >Air Lamp</ion-label\n                >\n              </ion-col>\n            </ion-row>\n            <ion-row>\n              <ion-col >\n                <ion-toggle\n                  (ionChange)=\"bak($event)\"\n                  [enableOnOffLabels]=\"true\"\n                  mode=\"ios\"\n                ></ion-toggle>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n        </div>\n      </ion-col>\n\n      <ion-col size=\"4\">\n        <div class=\"box2\">\n          <ion-grid>\n            <ion-row>\n              <ion-icon\n                class=\"aa\"\n                style=\"\n                  font-size: xx-large;\n                  color: gray;\n                  padding: 12px;\n                  padding-bottom: 0px;\n                \"\n                name=\"bulb\"\n              ></ion-icon\n            ></ion-row>\n            <ion-row>\n              <ion-col>\n                <ion-label\n                  style=\"padding: 0px 0px 13px 13px; font-family: sans-serif\"\n                  >Air Lamp</ion-label\n                >\n              </ion-col>\n            </ion-row>\n            <ion-row>\n              <ion-col>\n                <ion-toggle\n                  (ionChange)=\"bak($event)\"\n                  [enableOnOffLabels]=\"true\"\n                  mode=\"ios\"\n                ></ion-toggle>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n        </div>\n      </ion-col>\n    </ion-row>\n\n\n    <ion-row style=\"margin-bottom: -16%;\">\n      <ion-col size=\"4 \">\n        <div class=\"box3\">\n          <ion-grid style=\"padding: 13px\">\n            <ion-row>\n              <ion-col><ion-icon name=\"options\"></ion-icon></ion-col>\n            </ion-row>\n            <ion-row>\n              <ion-col><ion-label>Kontrol</ion-label></ion-col>\n            </ion-row>\n            <ion-row>\n              <ion-col><ion-label>Merkezi</ion-label></ion-col>\n            </ion-row>\n          </ion-grid>\n        </div>\n      </ion-col>\n\n      <ion-col size=\"4\">\n        <div class=\"box2\">\n          <ion-grid>\n            <ion-row>\n              <ion-icon\n                class=\"aa\"\n                style=\"\n                  font-size: xx-large;\n                  color: gray;\n                  padding: 12px;\n                  padding-bottom: 0px;\n                \"\n                name=\"bulb\"\n              ></ion-icon\n            ></ion-row>\n            <ion-row>\n              <ion-col>\n                <ion-label\n                  style=\"padding: 0px 0px 13px 13px; font-family: sans-serif\"\n                  >Air Lamp</ion-label\n                >\n              </ion-col>\n            </ion-row>\n            <ion-row>\n              <ion-col >\n                <ion-toggle\n                  (ionChange)=\"bak($event)\"\n                  [enableOnOffLabels]=\"true\"\n                  mode=\"ios\"\n                ></ion-toggle>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n        </div>\n      </ion-col>\n\n      <ion-col size=\"4\">\n        <div class=\"box2\">\n          <ion-grid>\n            <ion-row>\n              <ion-icon\n                class=\"aa\"\n                style=\"\n                  font-size: xx-large;\n                  color: gray;\n                  padding: 12px;\n                  padding-bottom: 0px;\n                \"\n                name=\"bulb\"\n              ></ion-icon\n            ></ion-row>\n            <ion-row>\n              <ion-col>\n                <ion-label\n                  style=\"padding: 0px 0px 13px 13px; font-family: sans-serif\"\n                  >Air Lamp</ion-label\n                >\n              </ion-col>\n            </ion-row>\n            <ion-row>\n              <ion-col>\n                <ion-toggle\n                  (ionChange)=\"bak($event)\"\n                  [enableOnOffLabels]=\"true\"\n                  mode=\"ios\"\n                ></ion-toggle>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n        </div>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n\n\n\n\n\n</ion-content>\n\n\n  <ion-tab-bar color=\"danger\" slot=\"bottom\">\n    <ion-tab-button selected=\"true\">\n      <ion-icon name=\"home\"></ion-icon>\n    </ion-tab-button>\n    <ion-tab-button>\n      <ion-icon name=\"library\"></ion-icon>\n    </ion-tab-button>\n    <ion-tab-button>\n      <ion-icon name=\"person\"></ion-icon>\n    </ion-tab-button>\n  </ion-tab-bar>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_demo_demo_module_ts.js.map