(self["webpackChunkselsmart"] = self["webpackChunkselsmart"] || []).push([["src_app_blue_blue_module_ts"],{

/***/ 1704:
/*!*********************************************!*\
  !*** ./src/app/blue/blue-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BluePageRoutingModule": () => (/* binding */ BluePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _blue_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./blue.page */ 7849);




const routes = [
    {
        path: '',
        component: _blue_page__WEBPACK_IMPORTED_MODULE_0__.BluePage
    }
];
let BluePageRoutingModule = class BluePageRoutingModule {
};
BluePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], BluePageRoutingModule);



/***/ }),

/***/ 3634:
/*!*************************************!*\
  !*** ./src/app/blue/blue.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BluePageModule": () => (/* binding */ BluePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 9122);
/* harmony import */ var _blue_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./blue-routing.module */ 1704);
/* harmony import */ var _blue_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./blue.page */ 7849);







let BluePageModule = class BluePageModule {
};
BluePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _blue_routing_module__WEBPACK_IMPORTED_MODULE_0__.BluePageRoutingModule
        ],
        declarations: [_blue_page__WEBPACK_IMPORTED_MODULE_1__.BluePage]
    })
], BluePageModule);



/***/ }),

/***/ 7849:
/*!***********************************!*\
  !*** ./src/app/blue/blue.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BluePage": () => (/* binding */ BluePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _raw_loader_blue_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./blue.page.html */ 7725);
/* harmony import */ var _blue_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./blue.page.scss */ 2371);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/platform-browser */ 9075);
/* harmony import */ var _services_profile_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/profile.service */ 7715);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 9122);







let BluePage = class BluePage {
    constructor(sanitizer, profile, loadingCtrl, navctrl) {
        this.sanitizer = sanitizer;
        this.profile = profile;
        this.loadingCtrl = loadingCtrl;
        this.navctrl = navctrl;
    }
    ionViewWillEnter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            this.profile.getUserProfile();
            console.log(this.iframeSrc);
            console.log(this.profile.useridsi);
        });
    }
    /*
    async blesiken() {
      console.log('clicked');
  
      try {
        const mobileNavigatorObject: any = window.navigator;
        const SERVICE_UUID = '6e400001-b5a3-f393-e0a9-e50e24dcca9e';
        const CHARACTERISTIC_UUID_TX = '6e400003-b5a3-f393-e0a9-e50e24dcca9e';
  
        if (mobileNavigatorObject && mobileNavigatorObject.bluetooth) {
          const device = await mobileNavigatorObject.bluetooth.requestDevice({
            acceptAllDevices: true,
            optionalServices: [SERVICE_UUID],
          });
  
          console.log('Cihaz adı:', device.name);
          const server = await device.gatt.connect();
          console.log('Cihaza bağlanıldı:', server);
          const service = await server.getPrimaryService(SERVICE_UUID);
          const characteristic = await service.getCharacteristic(CHARACTERISTIC_UUID_TX);
          console.log('Karakteristik bulundu.');
          this.characteristic = characteristic;
  
          const notifyData = new TextEncoder().encode('wifitara');
  
          await this.characteristic.writeValue(notifyData);
          console.log('Veri gönderildi.');
        }
      } catch (error) {
        console.error('İşlem hatası:', error);
      }
    }
  
  
    */
    blesiken() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            console.log('clicked');
            try {
                const mobileNavigatorObject = window.navigator;
                const SERVICE_UUID = '6e400001-b5a3-f393-e0a9-e50e24dcca9e';
                const CHARACTERISTIC_UUID_TX = '6e400003-b5a3-f393-e0a9-e50e24dcca9e';
                if (mobileNavigatorObject && mobileNavigatorObject.bluetooth) {
                    const device = yield mobileNavigatorObject.bluetooth.requestDevice({
                        acceptAllDevices: true,
                        optionalServices: [SERVICE_UUID],
                    });
                    console.log('Cihaz adı:', device.name);
                    const server = yield device.gatt.connect();
                    console.log('Cihaza bağlanıldı:', server);
                    const service = yield server.getPrimaryService(SERVICE_UUID);
                    const characteristic = yield service.getCharacteristic(CHARACTERISTIC_UUID_TX);
                    console.log('Karakteristik bulundu.');
                    this.characteristic = characteristic;
                    const notifyData = new TextEncoder().encode('wifitara');
                    yield this.characteristic.writeValue(notifyData);
                    console.log('Veri gönderildi.');
                }
            }
            catch (error) {
                console.error('İşlem hatası:', error);
                // Hata durumunu daha ayrıntılı incelemek için konsol çıktısını kontrol edin.
            }
        });
    }
    press() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            if (this.characteristic) {
                const notifyData = new TextEncoder().encode('wifitara');
                try {
                    yield this.characteristic.writeValue(notifyData);
                    console.log('Veri gönderildi.');
                }
                catch (error) {
                    console.error('Veri gönderme hatası:', error);
                }
            }
        });
    }
    back() {
        console.log('move to back');
    }
    gec() {
        this.navctrl.navigateRoot("home");
    }
    demo(e) {
        console.log(e);
    }
    openIframe() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            this.iframeSrc = this.sanitizer.bypassSecurityTrustResourceUrl('http://192.168.4.1/paramsave?input=' + this.profile.useridsi);
            // Belirli bir süre sonra iframe'in adresini değiştir
            const loading = yield this.loadingCtrl.create({
                message: 'Cihaza Bağlanılıyor...',
                duration: 10000,
            });
            loading.present().then(r => {
                setTimeout(() => {
                    this.changeIframeSrc();
                    console.log("işlem tamam");
                }, 3011);
            });
        });
    }
    changeIframeSrc() {
        // Iframe'in src'sini güvenli bir biçimde değiştirerek başka bir sayfaya yönlendirin
        this.iframeSrc = this.sanitizer.bypassSecurityTrustResourceUrl('http://192.168.4.1/wifi');
    }
};
BluePage.ctorParameters = () => [
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__.DomSanitizer },
    { type: _services_profile_service__WEBPACK_IMPORTED_MODULE_2__.ProfileService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController }
];
BluePage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-blue',
        template: _raw_loader_blue_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_blue_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], BluePage);



/***/ }),

/***/ 2371:
/*!*************************************!*\
  !*** ./src/app/blue/blue.page.scss ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-slides {\n  height: 100%;\n}\n\n.swiper-slide {\n  display: block;\n}\n\n.swiper-slide h2 {\n  margin-top: 2.8rem;\n}\n\n.swiper-slide img {\n  max-height: 50%;\n  max-width: 80%;\n  margin: 60px 0 40px;\n  margin-top: 35%;\n  pointer-events: none;\n}\n\nb {\n  font-weight: 500;\n}\n\np {\n  padding: 0 40px;\n  font-size: 14px;\n  line-height: 1.5;\n  color: var(--ion-color-step-600, #60646b);\n}\n\np b {\n  color: var(--ion-text-color, #000000);\n}\n\n:root {\n  --ion-safe-area-top: 20px;\n  --ion-safe-area-bottom: 22px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJsdWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsWUFBQTtBQUNGOztBQUVBO0VBQ0UsY0FBQTtBQUNGOztBQUVBO0VBQ0Usa0JBQUE7QUFDRjs7QUFFQTtFQUNFLGVBQUE7RUFDQSxjQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBRUEsb0JBQUE7QUFBRjs7QUFJQTtFQUNFLGdCQUFBO0FBREY7O0FBSUE7RUFDRSxlQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EseUNBQUE7QUFERjs7QUFJQTtFQUNFLHFDQUFBO0FBREY7O0FBR0E7RUFDRSx5QkFBQTtFQUNBLDRCQUFBO0FBQUYiLCJmaWxlIjoiYmx1ZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tc2xpZGVzIHtcbiAgaGVpZ2h0OiAxMDAlO1xufVxuXG4uc3dpcGVyLXNsaWRlIHtcbiAgZGlzcGxheTogYmxvY2s7XG59XG5cbi5zd2lwZXItc2xpZGUgaDIge1xuICBtYXJnaW4tdG9wOiAyLjhyZW07XG59XG5cbi5zd2lwZXItc2xpZGUgaW1nIHtcbiAgbWF4LWhlaWdodDogNTAlO1xuICBtYXgtd2lkdGg6IDgwJTtcbiAgbWFyZ2luOiA2MHB4IDAgNDBweDtcbiAgbWFyZ2luLXRvcDogMzUlO1xuXG4gIHBvaW50ZXItZXZlbnRzOiBub25lO1xufVxuXG5cbmIge1xuICBmb250LXdlaWdodDogNTAwO1xufVxuXG5wIHtcbiAgcGFkZGluZzogMCA0MHB4O1xuICBmb250LXNpemU6IDE0cHg7XG4gIGxpbmUtaGVpZ2h0OiAxLjU7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc3RlcC02MDAsICM2MDY0NmIpO1xufVxuXG5wIGIge1xuICBjb2xvcjogdmFyKC0taW9uLXRleHQtY29sb3IsICMwMDAwMDApO1xufVxuOnJvb3Qge1xuICAtLWlvbi1zYWZlLWFyZWEtdG9wOiAyMHB4O1xuICAtLWlvbi1zYWZlLWFyZWEtYm90dG9tOiAyMnB4O1xufVxuIl19 */");

/***/ }),

/***/ 7725:
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/blue/blue.page.html ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n\n<!--\n<div class=\"bg\">\n\n  <ion-row>\n    <ion-label style=\"margin: 5%; font-size: xx-large;\">\n      <ion-icon (click)=\"back()\" style=\"margin-bottom: -5px;\" name=\"arrow-back-circle\"></ion-icon>\n      Cihaz Bağla</ion-label>\n    <ion-col style=\"text-align: right;\">\n\n  <ion-button  (click)=\"blesiken()\" size=\"large\" style=\"width: 56px;\" shape=\"round\" fill=\"clear\">\n    <ion-icon   style=\"font-size: xxx-large; position: absolute\" color=\"dark\" name=\"reload-circle\"></ion-icon>\n  </ion-button>\n    </ion-col>\n  </ion-row>\n\n\n  <div class=\"round\" (click)=\"press()\">\n    <ion-icon name=\"bluetooth\"></ion-icon>\n    <ion-label >Selsmart</ion-label>\n  </div>\n\n</div>\n-->\n\n\n\n\n<ion-content fullscreen class=\"ion-padding\" scroll-y=\"false\">\n  <ion-slides pager=\"true\" (ionSlideDidChange)=\"demo($event)\">\n    <ion-slide id=\"1\">\n      <div class=\"slide\">\n        <img src=\"../../assets/img/1.svg\" />\n        <h2>Nasıl Cihazımı Bağlarım</h2>\n        <p>\n          Bu yönerge ile SelSmart cihazlarınızı kolayca intarnete bağlayabilirsiniz.\n        </p>\n      </div>\n    </ion-slide>\n\n    <ion-slide id=\"2\">\n      <img src=\"../../assets/img/5.svg\" />\n      <h2>WiFi bağlantınızı yapın</h2>\n      <p>\n        Cihazınızın güç bağlantısını yapın daha sonrasında uygulamaya dönün\n            </p>\n    </ion-slide>\n\n    <ion-slide id=\"3\">\n      <img src=\"../../assets/img/3.svg\" />\n      <h2>\n          WiFi ağına bağlandı isek\n      </h2>\n      <p>\n        Selsmart wifi ağına bağlandı iseniz her şey tamam demektir sıradaki adım Cihaza bağlan butonuna basmak ve cihazı wifi\n        bilgilerini girmek olacak.      </p>\n    </ion-slide>\n\n    <ion-slide>\n\n    <ion-button (click)=\"openIframe()\">Cihaza bağlan </ion-button>\n\n    <!-- Iframe -->\n    <iframe *ngIf=\"iframeSrc\" [src]=\"iframeSrc\" style=\"    width: 100%;\n    height: 90%;\n    box-shadow: none;\n    border-style: none;\"></iframe>\n\n    </ion-slide>\n\n\n\n\n    <ion-slide>\n      <img src=\"../../assets/img/4.svg\" />\n      <h2>Harika Cihaz eklendi !</h2>\n      <ion-button (click)=\"gec()\" fill=\"clear\">Ana ekrana dön <ion-icon slot=\"end\" name=\"arrow-forward\"></ion-icon></ion-button>\n    </ion-slide>\n  </ion-slides>\n\n\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_blue_blue_module_ts.js.map