(self["webpackChunkselsmart"] = self["webpackChunkselsmart"] || []).push([["src_app_demos_demos_module_ts"],{

/***/ 2213:
/*!***********************************************!*\
  !*** ./src/app/demos/demos-routing.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DemosPageRoutingModule": () => (/* binding */ DemosPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _demos_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./demos.page */ 4313);




const routes = [
    {
        path: '',
        component: _demos_page__WEBPACK_IMPORTED_MODULE_0__.DemosPage
    }
];
let DemosPageRoutingModule = class DemosPageRoutingModule {
};
DemosPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], DemosPageRoutingModule);



/***/ }),

/***/ 9242:
/*!***************************************!*\
  !*** ./src/app/demos/demos.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DemosPageModule": () => (/* binding */ DemosPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 9122);
/* harmony import */ var _demos_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./demos-routing.module */ 2213);
/* harmony import */ var _demos_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./demos.page */ 4313);







let DemosPageModule = class DemosPageModule {
};
DemosPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _demos_routing_module__WEBPACK_IMPORTED_MODULE_0__.DemosPageRoutingModule
        ],
        declarations: [_demos_page__WEBPACK_IMPORTED_MODULE_1__.DemosPage]
    })
], DemosPageModule);



/***/ }),

/***/ 4313:
/*!*************************************!*\
  !*** ./src/app/demos/demos.page.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DemosPage": () => (/* binding */ DemosPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _raw_loader_demos_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./demos.page.html */ 4926);
/* harmony import */ var _demos_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./demos.page.scss */ 6775);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);




let DemosPage = class DemosPage {
    constructor() {
        this.sayfano = 0;
    }
    ngOnInit() {
        this.updatebar();
    }
    bak(e) {
        this.sayfano++;
        console.log(this.sayfano);
        this.updatebar();
    }
    bak2(e) {
        this.sayfano--;
        console.log(this.sayfano);
        this.updatebar();
    }
    updatebar() {
        if (this.sayfano == 0) {
            document.getElementById("0").setAttribute("selected", "true");
        }
        else if (this.sayfano == 1) {
            document.getElementById("1").setAttribute("selected", "true");
        }
        else if (this.sayfano == 2) {
            document.getElementById("2").setAttribute("selected", "true");
        }
    }
};
DemosPage.ctorParameters = () => [];
DemosPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-demos',
        template: _raw_loader_demos_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_demos_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], DemosPage);



/***/ }),

/***/ 6775:
/*!***************************************!*\
  !*** ./src/app/demos/demos.page.scss ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkZW1vcy5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ 4926:
/*!*****************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/demos/demos.page.html ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n\n<ion-content fullscreen class=\"ion-padding\" scroll-y=\"false\">\n<h1>selam</h1>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_demos_demos_module_ts.js.map