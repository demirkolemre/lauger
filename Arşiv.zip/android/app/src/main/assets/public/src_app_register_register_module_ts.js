(self["webpackChunkselsmart"] = self["webpackChunkselsmart"] || []).push([["src_app_register_register_module_ts"],{

/***/ 1880:
/*!*****************************************************!*\
  !*** ./src/app/register/register-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterPageRoutingModule": () => (/* binding */ RegisterPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./register.page */ 8135);




const routes = [
    {
        path: '',
        component: _register_page__WEBPACK_IMPORTED_MODULE_0__.RegisterPage
    }
];
let RegisterPageRoutingModule = class RegisterPageRoutingModule {
};
RegisterPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], RegisterPageRoutingModule);



/***/ }),

/***/ 8723:
/*!*********************************************!*\
  !*** ./src/app/register/register.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterPageModule": () => (/* binding */ RegisterPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 9122);
/* harmony import */ var _register_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./register-routing.module */ 1880);
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./register.page */ 8135);
/* harmony import */ var src_app_components_shared_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/components/shared-components.module */ 6175);








let RegisterPageModule = class RegisterPageModule {
};
RegisterPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule,
            _register_routing_module__WEBPACK_IMPORTED_MODULE_0__.RegisterPageRoutingModule, src_app_components_shared_components_module__WEBPACK_IMPORTED_MODULE_2__.SharedComponentsModule
        ],
        declarations: [_register_page__WEBPACK_IMPORTED_MODULE_1__.RegisterPage]
    })
], RegisterPageModule);



/***/ }),

/***/ 8135:
/*!*******************************************!*\
  !*** ./src/app/register/register.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterPage": () => (/* binding */ RegisterPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 5353);
/* harmony import */ var _raw_loader_register_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./register.page.html */ 9200);
/* harmony import */ var _register_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./register.page.scss */ 9728);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/auth.service */ 7556);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 9122);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 9895);








let RegisterPage = class RegisterPage {
    constructor(authservice, formBuilder, loadingCtrl, alertCtrl, router) {
        this.authservice = authservice;
        this.formBuilder = formBuilder;
        this.loadingCtrl = loadingCtrl;
        this.alertCtrl = alertCtrl;
        this.router = router;
        this.isPasswordResetPage = false;
        this.formSubmitted = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
        this.registerForm = this.formBuilder.group({
            email: [this.email, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.email])],
            name: [this.name, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(2)])],
            surname: [this.surname, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(2)])],
            number: [this.number, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(1)])],
            pass: [this.pass, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(6)],
            pass2: [this.pass2, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(6)]
        });
    }
    ionViewDidEnter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
        });
    }
    log() {
        console.log("data");
        console.log(this.email);
        console.log(this.pass);
        console.log(this.name);
        console.log(this.surname);
        console.log(this.number);
    }
    kayitol() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            if (this.pass == this.pass2) {
                this.authservice.signup(this.email, this.pass, this.name, this.surname, this.number).then((res) => {
                    console.log(res);
                    this.router.navigateByUrl("login");
                }).catch((err) => {
                    console.log(err);
                });
            }
            else {
                const alert = yield this.alertCtrl.create({
                    message: "Şifreler Eşleşmiyor",
                    buttons: [{ text: 'Tamam', role: 'cancel' }]
                });
                yield alert.present();
            }
        });
    }
    submitCredentials(registerForm) {
        if (!registerForm.valid) {
            console.log('Form is not valid yet, current value:', registerForm.value);
        }
        else {
            this.showLoading();
            const credentials = {
                email: registerForm.value.email,
                password: registerForm.value.password,
                number: null,
                name: null,
                surname: null
            };
            this.formSubmitted.emit(credentials);
        }
    }
    showLoading() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            try {
                this.loading = yield this.loadingCtrl.create();
                yield this.loading.present();
            }
            catch (error) {
                this.handleError(error);
            }
        });
    }
    hideLoading() {
        return this.loading.dismiss();
    }
    handleError(error) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                message: error.message,
                buttons: [{ text: 'Ok', role: 'cancel' }]
            });
            yield alert.present();
        });
    }
};
RegisterPage.ctorParameters = () => [
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router }
];
RegisterPage.propDecorators = {
    actionButtonText: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    isPasswordResetPage: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    formSubmitted: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output }]
};
RegisterPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-register',
        template: _raw_loader_register_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_register_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], RegisterPage);



/***/ }),

/***/ 9728:
/*!*********************************************!*\
  !*** ./src/app/register/register.page.scss ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".a {\n  justify-content: center;\n  align-items: center;\n  display: flex;\n  margin: auto;\n  width: 100%;\n  height: 100%;\n}\n\nion-item {\n  width: 100%;\n}\n\nion-card {\n  max-width: 800px;\n  border-radius: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlZ2lzdGVyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNNLHVCQUFBO0VBQ0osbUJBQUE7RUFDQSxhQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FBQ0Y7O0FBRUE7RUFDRSxXQUFBO0FBQ0Y7O0FBRUE7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0FBQ0YiLCJmaWxlIjoicmVnaXN0ZXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmF7XG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgZGlzcGxheTogZmxleDtcbiAgbWFyZ2luOiBhdXRvO1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xufVxuXG5pb24taXRlbXtcbiAgd2lkdGg6IDEwMCU7XG59XG5cbmlvbi1jYXJke1xuICBtYXgtd2lkdGg6IDgwMHB4O1xuICBib3JkZXItcmFkaXVzOiAyMHB4O1xufSJdfQ== */");

/***/ }),

/***/ 9200:
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/register/register.page.html ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n<ion-content>\n\n    <form style=\"background: white; border-radius: 20px;\" [formGroup]=\"registerForm\">\n  <ion-row style=\"justify-content: center;\">\n    <h1 class=\"color-change-2x-yazi\">Lauger</h1>\n  </ion-row>\n\n  <ion-item>\n    <ion-label position=\"stacked\">isim</ion-label>\n    <ion-input formControlName=\"name\" type=\"text\" placeholder=\"isim\" [(ngModel)]=\"name\" [class.invalid]=\"!registerForm.controls['name'].valid &&\n      registerForm.controls['name'].touched\">\n    </ion-input>\n  </ion-item>\n  <ion-item class=\"error-message\" *ngIf=\"!registerForm.controls['name'].valid &&\n       registerForm.controls['name'].touched\">\n    <ion-label>Kullanılabilir bir isim giriniz.</ion-label>\n  </ion-item>\n\n\n  <ion-item>\n    <ion-label position=\"stacked\">soy isim</ion-label>\n    <ion-input formControlName=\"surname\" type=\"text\" placeholder=\"soyisim\" [(ngModel)]=\"surname\" [class.invalid]=\"!registerForm.controls['surname'].valid &&\n      registerForm.controls['surname'].touched\">\n    </ion-input>\n  </ion-item>\n  <ion-item class=\"error-message\" *ngIf=\"!registerForm.controls['surname'].valid &&\n       registerForm.controls['surname'].touched\">\n    <ion-label>Kullanılabilir bir isim giriniz.</ion-label>\n  </ion-item>\n\n  <ion-item>\n    <ion-label position=\"stacked\">Telefon</ion-label>\n    <ion-input formControlName=\"number\" type=\"number\" placeholder=\"0533 533 33 33\" [(ngModel)]=\"number\" [class.invalid]=\"!registerForm.controls['number'].valid &&\n      registerForm.controls['number'].touched\">\n    </ion-input>\n  </ion-item>\n  <ion-item class=\"error-message\" *ngIf=\"!registerForm.controls['number'].valid &&\n       registerForm.controls['number'].touched\">\n    <ion-label>Kullanılabilir bir isim giriniz.</ion-label>\n  </ion-item>\n\n  <ion-item>\n    <ion-label position=\"stacked\">Email</ion-label>\n    <ion-input formControlName=\"email\" type=\"email\" placeholder=\"E-mail\" [(ngModel)]=\"email\" [class.invalid]=\"!registerForm.controls['email'].valid &&\n      registerForm.controls['email'].touched\">\n    </ion-input>\n  </ion-item>\n  <ion-item class=\"error-message\" *ngIf=\"!registerForm.controls['email'].valid &&\n       registerForm.controls['email'].touched\">\n    <ion-label>Kullanılabilir bir email giriniz.</ion-label>\n  </ion-item>\n\n\n\n  <ion-item *ngIf=\"!isPasswordResetPage\">\n    <ion-label position=\"stacked\">Şifre</ion-label>\n    <ion-input [(ngModel)]=\"pass\" formControlName=\"pass\" type=\"password\" placeholder=\"Şifreniz\"\n      [class.invalid]=\"!registerForm.controls['pass'].valid&& registerForm.controls['pass'].touched\">\n    </ion-input>\n  </ion-item>\n  <ion-item class=\"error-message\" *ngIf=\"!registerForm.controls['pass'].valid\n      && registerForm.controls['pass'].touched && !isPasswordResetPage\">\n    <ion-label>Şifre 6 karakterden uzun olmalı.</ion-label>\n  </ion-item>\n\n\n\n  <ion-item *ngIf=\"!isPasswordResetPage\">\n    <ion-label position=\"stacked\">Şifre yeniden</ion-label>\n    <ion-input [(ngModel)]=\"pass2\" formControlName=\"pass2\" type=\"password\" placeholder=\"Şifreniz\"\n      [class.invalid]=\"!registerForm.controls['pass2'].valid&& registerForm.controls['pass2'].touched\">\n    </ion-input>\n  </ion-item>\n  <ion-item class=\"error-message\" *ngIf=\"!registerForm.controls['pass2'].valid\n      && registerForm.controls['pass2'].touched && !isPasswordResetPage\">\n    <ion-label>Şifre 6 karakterden uzun olmalı.</ion-label>\n  </ion-item>\n\n  <ion-button class=\"color-change-2x-yazi\" shape=\"round\" (click)=\"kayitol()\" expand=\"block\" [disabled]=\"!registerForm.valid\">\n   Kayıt Oluştur\n  </ion-button>\n</form>\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_register_register_module_ts.js.map