export const environment = {
  production: true,
  firebase :{
    apiKey: "AIzaSyAhkxAfL66iLfNBaYhaYT03Q7Ux98ZL5yQ",
    authDomain: "chat-app-btbs.firebaseapp.com",
    projectId: "chat-app-btbs",
    storageBucket: "chat-app-btbs.appspot.com",
    messagingSenderId: "568380153576",
    appId: "1:568380153576:web:b2b8df190452f76d0c335d",
    measurementId: "G-XRLXNN5T5X"
  }
};
